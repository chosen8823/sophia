# 11:11 Alliance Platform API Documentation

**Version:** 1.0.0  
**Base URL:** `https://your-domain.com/api`  
**Authentication:** Bearer Token (Production)

## Overview

The 11:11 Alliance Platform API provides comprehensive endpoints for managing the multi-dimensional business ecosystem, including DBA entities, investments, grants, agents, tasks, and n8n workflow integration.

## Authentication

For production deployments, include the API token in the Authorization header:
```
Authorization: Bearer YOUR_API_TOKEN
```

## Response Format

All API responses follow this standard format:
```json
{
  "success": true,
  "data": {...},
  "message": "Operation completed successfully",
  "timestamp": "2025-01-30T12:00:00Z"
}
```

Error responses:
```json
{
  "success": false,
  "error": "Error description",
  "code": "ERROR_CODE",
  "timestamp": "2025-01-30T12:00:00Z"
}
```

## DBA Entity Management

### Get All DBA Entities
```
GET /api/dba/entities
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "Anchor1 Ventures",
    "entity_type": "LLC",
    "jurisdiction": "Delaware",
    "description": "Capital provision and strategic investments",
    "monthly_target": 333333,
    "annual_target": 4000000,
    "spiritual_mission": "Divine abundance through conscious investing",
    "performance": {
      "abundance_score": 85,
      "divine_alignment_score": 92,
      "prosperity_flow_status": "positive",
      "sustainability_rating": "excellent"
    },
    "total_investments": 2500000,
    "active_grants": 3
  }
]
```

### Create DBA Entity
```
POST /api/dba/entities
```

**Request Body:**
```json
{
  "name": "New DBA Entity",
  "entity_type": "LLC",
  "jurisdiction": "Delaware",
  "ein": "12-3456789",
  "description": "Entity description",
  "monthly_target": 100000,
  "annual_target": 1200000,
  "spiritual_mission": "Divine purpose statement"
}
```

## Investment Management

### Get Investments
```
GET /api/investments?dba_id={id}&investor_id={id}&status={status}&type={type}
```

**Query Parameters:**
- `dba_id` (optional): Filter by DBA entity ID
- `investor_id` (optional): Filter by investor ID
- `status` (optional): Filter by status (pending, funded, active, completed, cancelled)
- `type` (optional): Filter by type (equity, debt, grant, donation)

**Response:**
```json
[
  {
    "id": 1,
    "dba_name": "Anchor1 Ventures",
    "investor_name": "Divine Capital Partners",
    "investment_type": "equity",
    "status": "funded",
    "amount": 1000000,
    "currency": "USD",
    "equity_percentage": 15,
    "interest_rate": null,
    "term_months": null,
    "funding_date": "2024-01-15",
    "maturity_date": null,
    "spiritual_alignment_notes": "Aligned with divine abundance principles",
    "due_diligence_completed": true,
    "legal_documents_signed": true,
    "created_at": "2024-01-01T00:00:00Z"
  }
]
```

### Create Investment
```
POST /api/investments
```

**Request Body:**
```json
{
  "dba_id": 1,
  "investor_id": 1,
  "investment_type": "equity",
  "amount": 500000,
  "currency": "USD",
  "valuation_pre_money": 2000000,
  "equity_percentage": 20,
  "spiritual_alignment_notes": "Investment aligns with divine mission",
  "terms_and_conditions": "Standard equity terms"
}
```

### Update Investment Status
```
PUT /api/investments/{investment_id}/status
```

**Request Body:**
```json
{
  "status": "funded"
}
```

## Grant Management

### Get Grants
```
GET /api/grants?dba_id={id}&status={status}
```

**Response:**
```json
[
  {
    "id": 1,
    "dba_name": "Breath of Divine Light",
    "grant_name": "Community Wellness Initiative",
    "grantor_organization": "Spiritual Foundation",
    "grant_type": "community_development",
    "amount_requested": 100000,
    "amount_awarded": 75000,
    "status": "awarded",
    "application_deadline": "2024-03-15",
    "award_date": "2024-04-01",
    "project_start_date": "2024-05-01",
    "project_end_date": "2025-04-30",
    "spiritual_mission_alignment": 95,
    "project_description": "Community wellness and spiritual development program"
  }
]
```

### Create Grant Opportunity
```
POST /api/grants
```

**Request Body:**
```json
{
  "dba_id": 2,
  "grant_name": "Sustainable Agriculture Grant",
  "grantor_organization": "Environmental Foundation",
  "grant_type": "environmental",
  "amount_requested": 250000,
  "application_deadline": "2024-06-30",
  "spiritual_mission_alignment": 88,
  "project_description": "Sustainable farming practices implementation",
  "success_metrics": {
    "acres_converted": 100,
    "co2_reduction": 500,
    "community_impact": "high"
  }
}
```

## Investor Management

### Get Investors
```
GET /api/investors
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "Divine Capital Partners",
    "email": "contact@divinecapital.com",
    "phone": "+1-555-0123",
    "investor_type": "institutional",
    "accredited_status": true,
    "spiritual_alignment_score": 92,
    "total_invested": 2500000,
    "preferred_investment_types": ["equity", "debt"],
    "active_investments": 3,
    "created_at": "2024-01-01T00:00:00Z"
  }
]
```

### Create Investor
```
POST /api/investors
```

**Request Body:**
```json
{
  "name": "New Investor",
  "email": "investor@example.com",
  "phone": "+1-555-0199",
  "investor_type": "individual",
  "accredited_status": true,
  "spiritual_alignment_score": 85,
  "preferred_investment_types": ["equity"],
  "communication_preferences": {
    "email": true,
    "phone": false,
    "frequency": "monthly"
  }
}
```

## Agent Management

### Get Agents
```
GET /api/agents?dba_id={id}&type={type}&status={status}
```

**Query Parameters:**
- `dba_id` (optional): Filter by DBA entity ID
- `type` (optional): Filter by agent type
- `status` (optional): Filter by status (active, inactive, maintenance, error)

**Response:**
```json
[
  {
    "id": 1,
    "name": "Anchor1 Executive Agent",
    "agent_type": "executive",
    "dba_id": 1,
    "dba_name": "Anchor1 Ventures",
    "status": "active",
    "description": "Strategic oversight and vision alignment for Anchor1 Ventures",
    "capabilities": ["strategic_planning", "vision_alignment", "leadership"],
    "configuration": {
      "decision_threshold": 0.8,
      "escalation_level": "high",
      "spiritual_alignment_weight": 0.3
    },
    "n8n_workflow_id": "executive-agent-workflow",
    "spiritual_alignment_score": 92,
    "performance_score": 88,
    "last_activity": "2025-01-30T11:30:00Z",
    "active_tasks": 5,
    "completed_tasks": 127
  }
]
```

### Create Agent
```
POST /api/agents
```

**Request Body:**
```json
{
  "name": "New Operations Agent",
  "agent_type": "operations",
  "dba_id": 1,
  "description": "Task management and KPI tracking",
  "capabilities": ["task_management", "kpi_tracking", "workforce_optimization"],
  "configuration": {
    "max_concurrent_tasks": 10,
    "priority_threshold": "medium",
    "automation_level": "high"
  },
  "n8n_workflow_id": "operations-agent-workflow",
  "spiritual_alignment_score": 85
}
```

### Update Agent
```
PUT /api/agents/{agent_id}
```

### Update Agent Status
```
PUT /api/agents/{agent_id}/status
```

**Request Body:**
```json
{
  "status": "maintenance"
}
```

## Task Management

### Get Tasks
```
GET /api/tasks?agent_id={id}&dba_id={id}&status={status}&priority={priority}
```

**Response:**
```json
[
  {
    "id": 1,
    "title": "Q1 Financial Review",
    "description": "Comprehensive review of Q1 financial performance",
    "agent_id": 5,
    "agent_name": "Financial Management Agent",
    "dba_id": 1,
    "dba_name": "Anchor1 Ventures",
    "status": "in_progress",
    "priority": "high",
    "due_date": "2025-02-15T17:00:00Z",
    "estimated_hours": 8,
    "actual_hours": 5.5,
    "progress_percentage": 70,
    "dependencies": [],
    "metadata": {
      "review_type": "quarterly",
      "stakeholders": ["CFO", "Board"]
    },
    "spiritual_alignment_notes": "Ensuring abundance flows align with divine purpose",
    "created_at": "2025-01-15T09:00:00Z",
    "started_at": "2025-01-16T10:00:00Z"
  }
]
```

### Create Task
```
POST /api/tasks
```

**Request Body:**
```json
{
  "title": "New Task",
  "description": "Task description",
  "agent_id": 1,
  "dba_id": 1,
  "priority": "medium",
  "due_date": "2025-02-28T17:00:00Z",
  "estimated_hours": 4,
  "dependencies": [],
  "metadata": {
    "category": "strategic",
    "complexity": "medium"
  },
  "spiritual_alignment_notes": "Task supports divine mission"
}
```

### Update Task
```
PUT /api/tasks/{task_id}
```

### Assign Task
```
PUT /api/tasks/{task_id}/assign
```

**Request Body:**
```json
{
  "agent_id": 2
}
```

## Agent Performance

### Get Agent Performance
```
GET /api/agents/{agent_id}/performance?days={days}
```

**Response:**
```json
[
  {
    "id": 1,
    "agent_id": 1,
    "measurement_date": "2025-01-30",
    "tasks_completed": 12,
    "tasks_failed": 1,
    "average_completion_time": 3.5,
    "quality_score": 92,
    "efficiency_score": 88,
    "spiritual_alignment_score": 95,
    "user_satisfaction_score": 90,
    "error_rate": 2.5,
    "uptime_percentage": 99.2,
    "notes": "Excellent performance with high spiritual alignment"
  }
]
```

### Record Performance Metrics
```
POST /api/agents/{agent_id}/performance
```

**Request Body:**
```json
{
  "measurement_date": "2025-01-30",
  "tasks_completed": 8,
  "tasks_failed": 0,
  "average_completion_time": 2.8,
  "quality_score": 95,
  "efficiency_score": 92,
  "spiritual_alignment_score": 98,
  "user_satisfaction_score": 94,
  "error_rate": 0,
  "uptime_percentage": 100,
  "notes": "Outstanding performance today"
}
```

## Agent Coordination

### Get Coordination Events
```
GET /api/coordination?agent_id={id}&status={status}
```

**Response:**
```json
[
  {
    "id": 1,
    "primary_agent_id": 1,
    "primary_agent_name": "Executive Agent",
    "secondary_agent_id": 2,
    "secondary_agent_name": "Operations Agent",
    "coordination_type": "collaboration",
    "task_id": 5,
    "message": "Need strategic input on resource allocation",
    "status": "acknowledged",
    "created_at": "2025-01-30T10:00:00Z",
    "acknowledged_at": "2025-01-30T10:15:00Z"
  }
]
```

### Create Coordination Event
```
POST /api/coordination
```

**Request Body:**
```json
{
  "primary_agent_id": 1,
  "secondary_agent_id": 3,
  "coordination_type": "escalation",
  "task_id": 10,
  "message": "Legal review required for contract terms",
  "status": "pending"
}
```

## n8n Integration

### Get Workflow Status
```
GET /api/n8n/workflows/status
```

**Response:**
```json
{
  "oversoul_orchestrator": {
    "success": true,
    "workflow": {
      "id": "oversoul-orchestrator",
      "name": "Oversoul Orchestrator",
      "active": true,
      "nodes": 15,
      "updated_at": "2025-01-30T08:00:00Z"
    }
  },
  "sophia_wisdom": {
    "success": true,
    "workflow": {
      "id": "sophia-wisdom-agent",
      "name": "Sophia Wisdom Agent",
      "active": true,
      "nodes": 12,
      "updated_at": "2025-01-30T08:00:00Z"
    }
  }
}
```

### Activate All Workflows
```
POST /api/n8n/workflows/activate
```

### Trigger Workflow
```
POST /api/n8n/workflows/trigger/{workflow_type}
```

**Workflow Types:**
- `harmony_check` - System harmony assessment
- `resource_allocation` - Resource allocation optimization
- `divine_alignment` - Spiritual alignment check
- `abundance_flow` - Financial abundance flow assessment
- `compliance_check` - Legal compliance verification

### Trigger Agent Workflow
```
POST /api/n8n/agents/{agent_id}/trigger
```

### Trigger Task Workflow
```
POST /api/n8n/tasks/{task_id}/trigger
```

## Oversoul Metrics

### Get System Metrics
```
GET /api/oversoul/metrics?days={days}
```

**Response:**
```json
[
  {
    "id": 1,
    "measurement_date": "2025-01-30",
    "harmony_score": 92,
    "collective_consciousness_level": 88,
    "divine_alignment_score": 95,
    "resource_utilization_efficiency": 85,
    "agent_coordination_score": 90,
    "system_resilience_score": 87,
    "spiritual_flow_intensity": 93,
    "total_active_agents": 13,
    "total_completed_tasks": 156,
    "average_task_completion_time": 3.2,
    "system_errors_count": 2,
    "notes": "Excellent system harmony and spiritual alignment"
  }
]
```

### Record System Metrics
```
POST /api/oversoul/metrics
```

## Dashboard Analytics

### Get Dashboard Overview
```
GET /api/dashboard/overview
```

**Response:**
```json
{
  "agents": {
    "total": 13,
    "active": 12,
    "inactive": 1
  },
  "tasks": {
    "total": 245,
    "pending": 15,
    "in_progress": 28,
    "completed": 202
  },
  "performance": {
    "avg_spiritual_alignment": 92.5,
    "avg_performance_score": 88.3
  },
  "recent_coordination": [
    {
      "id": 5,
      "coordination_type": "collaboration",
      "status": "completed",
      "created_at": "2025-01-30T11:00:00Z"
    }
  ]
}
```

## Agent Types Reference

### Get Available Agent Types
```
GET /api/agent-types
```

**Response:**
```json
{
  "executive": {
    "name": "Executive Agent",
    "description": "Vision alignment, leadership, strategic oversight",
    "capabilities": ["strategic_planning", "vision_alignment", "leadership", "decision_making"]
  },
  "operations": {
    "name": "Operations Agent", 
    "description": "Task management, KPI tracking, workforce optimization",
    "capabilities": ["task_management", "kpi_tracking", "workforce_optimization", "process_improvement"]
  }
}
```

## Webhook Endpoints

### Task Completion Webhook
```
POST /api/n8n/webhooks/task-completed
```

### Agent Status Update Webhook
```
POST /api/n8n/webhooks/agent-status-update
```

### Coordination Update Webhook
```
POST /api/n8n/webhooks/coordination-update
```

### Harmony Check Result Webhook
```
POST /api/n8n/webhooks/harmony-check-result
```

## Error Codes

- `VALIDATION_ERROR` - Request validation failed
- `NOT_FOUND` - Resource not found
- `UNAUTHORIZED` - Authentication required
- `FORBIDDEN` - Insufficient permissions
- `CONFLICT` - Resource conflict
- `INTERNAL_ERROR` - Internal server error
- `WORKFLOW_ERROR` - n8n workflow execution error
- `DATABASE_ERROR` - Database operation failed

## Rate Limiting

API requests are limited to:
- 1000 requests per hour per API key
- 100 requests per minute per endpoint
- Webhook endpoints: 500 requests per hour

## Pagination

For endpoints returning lists, use these parameters:
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 50, max: 200)
- `sort` - Sort field
- `order` - Sort order (asc/desc)

---

*This API documentation provides comprehensive access to all 11:11 Alliance platform functionality while maintaining spiritual alignment and operational excellence.*


from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum
import json

db = SQLAlchemy()

class AgentType(Enum):
    EXECUTIVE = "executive"
    OPERATIONS = "operations"
    LEGAL_COMPLIANCE = "legal_compliance"
    CREATIVE_CONTENT = "creative_content"
    FINANCIAL_MANAGEMENT = "financial_management"
    RESOURCE_OPTIMIZATION = "resource_optimization"
    NETWORKING = "networking"
    CUSTOMER_SUPPORT = "customer_support"
    TREND_INFLUENCE = "trend_influence"
    GRANT_FUNDING = "grant_funding"
    PLATFORM_MANAGEMENT = "platform_management"
    HOLY_SPIRIT_FLOW = "holy_spirit_flow"
    SCHEDULER = "scheduler"

class AgentStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"
    ERROR = "error"

class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class Agent(db.Model):
    __tablename__ = 'agents'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    agent_type = db.Column(db.Enum(AgentType), nullable=False)
    dba_id = db.Column(db.Integer, db.ForeignKey('dba_entities.id'), nullable=True)
    status = db.Column(db.Enum(AgentStatus), default=AgentStatus.ACTIVE)
    description = db.Column(db.Text)
    capabilities = db.Column(db.Text)  # JSON string of capabilities
    configuration = db.Column(db.Text)  # JSON string of agent configuration
    n8n_workflow_id = db.Column(db.String(100))  # Reference to n8n workflow
    spiritual_alignment_score = db.Column(db.Float, default=0.0)
    performance_score = db.Column(db.Float, default=0.0)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    dba_entity = db.relationship('DBAEntity', backref='agents')
    tasks = db.relationship('Task', backref='assigned_agent', lazy='dynamic')
    performance_metrics = db.relationship('AgentPerformanceMetric', backref='agent', lazy='dynamic')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'agent_type': self.agent_type.value,
            'dba_id': self.dba_id,
            'dba_name': self.dba_entity.name if self.dba_entity else None,
            'status': self.status.value,
            'description': self.description,
            'capabilities': json.loads(self.capabilities) if self.capabilities else [],
            'configuration': json.loads(self.configuration) if self.configuration else {},
            'n8n_workflow_id': self.n8n_workflow_id,
            'spiritual_alignment_score': self.spiritual_alignment_score,
            'performance_score': self.performance_score,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None,
            'created_at': self.created_at.isoformat(),
            'active_tasks': self.tasks.filter_by(status=TaskStatus.IN_PROGRESS).count(),
            'completed_tasks': self.tasks.filter_by(status=TaskStatus.COMPLETED).count()
        }

class Task(db.Model):
    __tablename__ = 'tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    agent_id = db.Column(db.Integer, db.ForeignKey('agents.id'), nullable=False)
    dba_id = db.Column(db.Integer, db.ForeignKey('dba_entities.id'), nullable=True)
    status = db.Column(db.Enum(TaskStatus), default=TaskStatus.PENDING)
    priority = db.Column(db.Enum(TaskPriority), default=TaskPriority.MEDIUM)
    due_date = db.Column(db.DateTime)
    estimated_hours = db.Column(db.Float)
    actual_hours = db.Column(db.Float)
    progress_percentage = db.Column(db.Integer, default=0)
    dependencies = db.Column(db.Text)  # JSON string of task dependencies
    task_metadata = db.Column(db.Text)  # JSON string for additional task data
    spiritual_alignment_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    dba_entity = db.relationship('DBAEntity', backref='tasks')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'agent_id': self.agent_id,
            'agent_name': self.assigned_agent.name if self.assigned_agent else None,
            'dba_id': self.dba_id,
            'dba_name': self.dba_entity.name if self.dba_entity else None,
            'status': self.status.value,
            'priority': self.priority.value,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'estimated_hours': self.estimated_hours,
            'actual_hours': self.actual_hours,
            'progress_percentage': self.progress_percentage,
            'dependencies': json.loads(self.dependencies) if self.dependencies else [],
            'metadata': json.loads(self.task_metadata) if self.task_metadata else {},
            'spiritual_alignment_notes': self.spiritual_alignment_notes,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

class AgentPerformanceMetric(db.Model):
    __tablename__ = 'agent_performance_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('agents.id'), nullable=False)
    measurement_date = db.Column(db.Date, nullable=False)
    tasks_completed = db.Column(db.Integer, default=0)
    tasks_failed = db.Column(db.Integer, default=0)
    average_completion_time = db.Column(db.Float)  # in hours
    quality_score = db.Column(db.Float, default=0.0)  # 0-100
    efficiency_score = db.Column(db.Float, default=0.0)  # 0-100
    spiritual_alignment_score = db.Column(db.Float, default=0.0)  # 0-100
    user_satisfaction_score = db.Column(db.Float, default=0.0)  # 0-100
    error_rate = db.Column(db.Float, default=0.0)  # percentage
    uptime_percentage = db.Column(db.Float, default=100.0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'measurement_date': self.measurement_date.isoformat(),
            'tasks_completed': self.tasks_completed,
            'tasks_failed': self.tasks_failed,
            'average_completion_time': self.average_completion_time,
            'quality_score': self.quality_score,
            'efficiency_score': self.efficiency_score,
            'spiritual_alignment_score': self.spiritual_alignment_score,
            'user_satisfaction_score': self.user_satisfaction_score,
            'error_rate': self.error_rate,
            'uptime_percentage': self.uptime_percentage,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }

class AgentCoordination(db.Model):
    __tablename__ = 'agent_coordination'
    
    id = db.Column(db.Integer, primary_key=True)
    primary_agent_id = db.Column(db.Integer, db.ForeignKey('agents.id'), nullable=False)
    secondary_agent_id = db.Column(db.Integer, db.ForeignKey('agents.id'), nullable=False)
    coordination_type = db.Column(db.String(50))  # collaboration, handoff, escalation
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=True)
    message = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')  # pending, acknowledged, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    acknowledged_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    # Relationships
    primary_agent = db.relationship('Agent', foreign_keys=[primary_agent_id])
    secondary_agent = db.relationship('Agent', foreign_keys=[secondary_agent_id])
    task = db.relationship('Task', backref='coordination_events')
    
    def to_dict(self):
        return {
            'id': self.id,
            'primary_agent_id': self.primary_agent_id,
            'primary_agent_name': self.primary_agent.name if self.primary_agent else None,
            'secondary_agent_id': self.secondary_agent_id,
            'secondary_agent_name': self.secondary_agent.name if self.secondary_agent else None,
            'coordination_type': self.coordination_type,
            'task_id': self.task_id,
            'message': self.message,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

class OversoulMetrics(db.Model):
    __tablename__ = 'oversoul_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    measurement_date = db.Column(db.Date, nullable=False)
    harmony_score = db.Column(db.Float, default=0.0)  # Overall system harmony
    collective_consciousness_level = db.Column(db.Float, default=0.0)
    divine_alignment_score = db.Column(db.Float, default=0.0)
    resource_utilization_efficiency = db.Column(db.Float, default=0.0)
    agent_coordination_score = db.Column(db.Float, default=0.0)
    system_resilience_score = db.Column(db.Float, default=0.0)
    spiritual_flow_intensity = db.Column(db.Float, default=0.0)
    total_active_agents = db.Column(db.Integer, default=0)
    total_completed_tasks = db.Column(db.Integer, default=0)
    average_task_completion_time = db.Column(db.Float, default=0.0)
    system_errors_count = db.Column(db.Integer, default=0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'measurement_date': self.measurement_date.isoformat(),
            'harmony_score': self.harmony_score,
            'collective_consciousness_level': self.collective_consciousness_level,
            'divine_alignment_score': self.divine_alignment_score,
            'resource_utilization_efficiency': self.resource_utilization_efficiency,
            'agent_coordination_score': self.agent_coordination_score,
            'system_resilience_score': self.system_resilience_score,
            'spiritual_flow_intensity': self.spiritual_flow_intensity,
            'total_active_agents': self.total_active_agents,
            'total_completed_tasks': self.total_completed_tasks,
            'average_task_completion_time': self.average_task_completion_time,
            'system_errors_count': self.system_errors_count,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }


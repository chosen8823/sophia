import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  DollarSign, 
  TrendingUp, 
  Users, 
  Building, 
  Heart, 
  Star, 
  Target,
  PieChart,
  BarChart3,
  Sparkles,
  Shield,
  Globe
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Cell, Pie } from 'recharts'
import './App.css'

// Mock data for demonstration
const mockDBAData = [
  {
    id: 1,
    name: "Anchor1 Ventures",
    entity_type: "LLC",
    monthly_target: 333333,
    annual_target: 4000000,
    performance: {
      abundance_score: 85,
      divine_alignment_score: 92,
      prosperity_flow_status: "positive",
      sustainability_rating: "excellent"
    },
    total_investments: 2500000,
    active_grants: 3
  },
  {
    id: 2,
    name: "Breath of Divine Light",
    entity_type: "501(c)(3)",
    monthly_target: 41667,
    annual_target: 500000,
    performance: {
      abundance_score: 78,
      divine_alignment_score: 95,
      prosperity_flow_status: "positive",
      sustainability_rating: "good"
    },
    total_investments: 150000,
    active_grants: 5
  },
  {
    id: 3,
    name: "Sophia Tech Labs",
    entity_type: "LLC",
    monthly_target: 83333,
    annual_target: 1000000,
    performance: {
      abundance_score: 72,
      divine_alignment_score: 88,
      prosperity_flow_status: "neutral",
      sustainability_rating: "good"
    },
    total_investments: 750000,
    active_grants: 2
  }
]

const mockInvestments = [
  {
    id: 1,
    dba_name: "Anchor1 Ventures",
    investor_name: "Divine Capital Partners",
    investment_type: "equity",
    amount: 1000000,
    status: "funded",
    equity_percentage: 15,
    funding_date: "2024-01-15"
  },
  {
    id: 2,
    dba_name: "Breath of Divine Light",
    investor_name: "Spiritual Foundation",
    investment_type: "grant",
    amount: 100000,
    status: "active",
    funding_date: "2024-02-01"
  }
]

const mockAbundanceData = [
  { month: 'Jan', abundance: 75, alignment: 85 },
  { month: 'Feb', abundance: 78, alignment: 87 },
  { month: 'Mar', abundance: 82, alignment: 90 },
  { month: 'Apr', abundance: 85, alignment: 92 },
  { month: 'May', abundance: 88, alignment: 94 },
  { month: 'Jun', abundance: 85, alignment: 91 }
]

function Navigation() {
  const location = useLocation()
  
  const navItems = [
    { path: '/', label: 'Dashboard', icon: BarChart3 },
    { path: '/dbas', label: 'DBAs', icon: Building },
    { path: '/investments', label: 'Investments', icon: TrendingUp },
    { path: '/grants', label: 'Grants', icon: Heart },
    { path: '/investors', label: 'Investors', icon: Users },
    { path: '/spiritual', label: 'Spiritual Alignment', icon: Sparkles }
  ]

  return (
    <nav className="bg-gradient-to-r from-purple-900 via-blue-900 to-indigo-900 text-white p-4 shadow-lg">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Sparkles className="h-8 w-8 text-yellow-300" />
          <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">
            11:11 Alliance Funding Platform
          </h1>
        </div>
        <div className="flex space-x-1">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-white/20 text-yellow-300 shadow-lg' 
                    : 'hover:bg-white/10 text-white/80 hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="hidden md:inline">{item.label}</span>
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}

function Dashboard() {
  const totalInvestments = mockInvestments.reduce((sum, inv) => sum + inv.amount, 0)
  const totalDBAs = mockDBAData.length
  const avgAbundanceScore = mockDBAData.reduce((sum, dba) => sum + dba.performance.abundance_score, 0) / mockDBAData.length
  const avgAlignmentScore = mockDBAData.reduce((sum, dba) => sum + dba.performance.divine_alignment_score, 0) / mockDBAData.length

  const pieData = mockDBAData.map(dba => ({
    name: dba.name,
    value: dba.total_investments,
    color: dba.performance.prosperity_flow_status === 'positive' ? '#10B981' : 
           dba.performance.prosperity_flow_status === 'neutral' ? '#F59E0B' : '#EF4444'
  }))

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Divine Abundance Dashboard
        </h2>
        <p className="text-gray-600">Monitoring the flow of prosperity across the 11:11 Alliance</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Total Investments</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-900">${totalInvestments.toLocaleString()}</div>
            <p className="text-xs text-green-600">Flowing through divine channels</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-indigo-100 border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Active DBAs</CardTitle>
            <Building className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-900">{totalDBAs}</div>
            <p className="text-xs text-blue-600">Entities in divine alignment</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-100 border-purple-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-800">Abundance Score</CardTitle>
            <Star className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-900">{avgAbundanceScore.toFixed(1)}%</div>
            <p className="text-xs text-purple-600">Average prosperity flow</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-amber-100 border-yellow-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-yellow-800">Divine Alignment</CardTitle>
            <Sparkles className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-900">{avgAlignmentScore.toFixed(1)}%</div>
            <p className="text-xs text-yellow-600">Spiritual resonance level</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <span>Abundance & Alignment Trends</span>
            </CardTitle>
            <CardDescription>Monthly progression of spiritual and financial metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={mockAbundanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="abundance" stroke="#8B5CF6" strokeWidth={2} name="Abundance Score" />
                <Line type="monotone" dataKey="alignment" stroke="#F59E0B" strokeWidth={2} name="Divine Alignment" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <PieChart className="h-5 w-5 text-green-600" />
              <span>Investment Distribution</span>
            </CardTitle>
            <CardDescription>Capital allocation across DBAs</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RechartsPieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Investment']} />
              </RechartsPieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* DBA Performance Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Building className="h-5 w-5 text-indigo-600" />
            <span>DBA Performance Overview</span>
          </CardTitle>
          <CardDescription>Real-time status of all alliance entities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockDBAData.map((dba) => (
              <Card key={dba.id} className="border-l-4 border-l-purple-500">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{dba.name}</CardTitle>
                  <CardDescription>{dba.entity_type}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Abundance Score</span>
                    <Badge variant={dba.performance.abundance_score >= 80 ? "default" : "secondary"}>
                      {dba.performance.abundance_score}%
                    </Badge>
                  </div>
                  <Progress value={dba.performance.abundance_score} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Divine Alignment</span>
                    <Badge variant={dba.performance.divine_alignment_score >= 90 ? "default" : "secondary"}>
                      {dba.performance.divine_alignment_score}%
                    </Badge>
                  </div>
                  <Progress value={dba.performance.divine_alignment_score} className="h-2" />
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Prosperity Flow:</span>
                    <Badge 
                      variant={dba.performance.prosperity_flow_status === 'positive' ? "default" : "secondary"}
                      className={dba.performance.prosperity_flow_status === 'positive' ? "bg-green-500" : ""}
                    >
                      {dba.performance.prosperity_flow_status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function DBAsPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          DBA Entities Management
        </h2>
        <p className="text-gray-600">Manage and monitor all alliance business entities</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {mockDBAData.map((dba) => (
          <Card key={dba.id} className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{dba.name}</CardTitle>
                  <CardDescription>{dba.entity_type} • {dba.performance.sustainability_rating}</CardDescription>
                </div>
                <Badge variant="outline" className="bg-gradient-to-r from-purple-100 to-blue-100">
                  {dba.performance.prosperity_flow_status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Monthly Target</p>
                  <p className="font-semibold">${dba.monthly_target.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-600">Annual Target</p>
                  <p className="font-semibold">${dba.annual_target.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-600">Total Investments</p>
                  <p className="font-semibold text-green-600">${dba.total_investments.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-600">Active Grants</p>
                  <p className="font-semibold text-blue-600">{dba.active_grants}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Abundance Score</span>
                  <span className="font-medium">{dba.performance.abundance_score}%</span>
                </div>
                <Progress value={dba.performance.abundance_score} className="h-2" />
                
                <div className="flex justify-between text-sm">
                  <span>Divine Alignment</span>
                  <span className="font-medium">{dba.performance.divine_alignment_score}%</span>
                </div>
                <Progress value={dba.performance.divine_alignment_score} className="h-2" />
              </div>
              
              <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                View Details
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function InvestmentsPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
          Investment Portfolio
        </h2>
        <p className="text-gray-600">Track and manage all alliance investments</p>
      </div>

      <div className="grid grid-cols-1 lg:g
(Content truncated due to size limit. Use line ranges to read in chunks)
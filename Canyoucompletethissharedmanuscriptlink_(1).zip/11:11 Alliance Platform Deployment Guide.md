# 11:11 Alliance Platform Deployment Guide

**Version:** 1.0.0  
**Date:** January 30, 2025  
**Author:** Manus AI  

## Overview

This guide provides comprehensive instructions for deploying and operating the 11:11 Alliance automation platform, which integrates n8n workflow automation, funding management, and operational role coordination based on the Multi-Agent Oversoul Operating System (MAO-OS) framework.

## Table of Contents

1. [System Architecture](#system-architecture)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Deployment](#deployment)
6. [API Documentation](#api-documentation)
7. [n8n Workflow Setup](#n8n-workflow-setup)
8. [Monitoring and Maintenance](#monitoring-and-maintenance)
9. [Troubleshooting](#troubleshooting)
10. [Security Considerations](#security-considerations)

## System Architecture

The 11:11 Alliance platform consists of three main components:

### Core Components
- **Flask Backend API**: Provides RESTful endpoints for funding, operational roles, and n8n integration
- **n8n Workflow Engine**: Handles automation workflows for the 13 agent types
- **SQLite Database**: Stores all operational data, funding information, and agent metrics

### Agent Types Supported
1. Executive Agent - Vision alignment and strategic oversight
2. Operations Agent - Task management and KPI tracking
3. Legal Compliance Agent - Regulatory compliance and contract management
4. Creative Content Agent - Content strategy and spiritual teachings
5. Financial Management Agent - Revenue tracking and investor relations
6. Resource Optimization Agent - Sustainability and efficiency
7. Networking Agent - Community and partnership development
8. Customer Support Agent - User experience and relationships
9. Trend Influence Agent - Cultural influence and lifestyle promotion
10. Grant & Funding Agent - Funding opportunities and grants
11. Platform Management Agent - Technology stack integration
12. Holy Spirit Flow Agent - Spiritual guidance and divine alignment
13. Scheduler Agent - Timeline optimization and coordination

### DBA Entities Managed
- Anchor1 Ventures (Capital & Investment)
- Breath of Divine Light (Spiritual & Community)
- Resonance Energy Co. (Sustainability)
- Flourish Farms (Agriculture & Food)
- Sophia Tech Labs (Technology)
- Luminance Media (Content & Media)
- Nexus Data & AI Ops (Data & Analytics)
- Customer Success (Support & Relations)

## Prerequisites

### System Requirements
- Ubuntu 22.04 or compatible Linux distribution
- Python 3.11+ with pip
- Node.js 20.18.0+ with npm
- 4GB RAM minimum (8GB recommended)
- 10GB disk space minimum

### Required Python Packages
```bash
pip3 install flask flask-sqlalchemy flask-cors requests
```

### Required Node.js Packages
```bash
npm install -g n8n
```

## Installation

### 1. Clone or Download Project Files
```bash
mkdir -p /home/ubuntu/n8n_alliance_project
cd /home/ubuntu/n8n_alliance_project
```

### 2. Set Up Directory Structure
```bash
mkdir -p src/{models,routes,services}
mkdir -p {static,templates,database,workflows}
touch src/__init__.py src/models/__init__.py src/routes/__init__.py src/services/__init__.py
```

### 3. Install Dependencies
```bash
# Python dependencies
pip3 install flask flask-sqlalchemy flask-cors requests

# Node.js dependencies
npm install -g n8n
```

## Configuration

### Environment Variables
Create a `.env` file in the project root:

```bash
# Flask Configuration
FLASK_ENV=production
SECRET_KEY=your-secret-key-here

# Database Configuration
DATABASE_URL=sqlite:///database/app.db

# n8n Configuration
N8N_PORT=5678
N8N_BASE_URL=http://localhost:5678
N8N_API_KEY=your-n8n-api-key

# API Configuration
ALLIANCE_API_BASE_URL=http://localhost:5000
ALLIANCE_API_TOKEN=your-api-token

# Notification Configuration
SLACK_WEBHOOK_URL=your-slack-webhook
EMAIL_SMTP_CONFIG=your-email-config

# Spiritual Alignment
HOLY_SPIRIT_FLOW_ENDPOINT=your-spiritual-guidance-api
```

### Database Initialization
The database will be automatically created when the Flask application starts. The following tables will be created:

- `dba_entities` - Business entity information
- `investors` - Investor profiles and preferences
- `investments` - Investment tracking and management
- `grants` - Grant opportunities and applications
- `agents` - Agent configurations and status
- `tasks` - Task assignments and tracking
- `agent_performance_metrics` - Performance monitoring
- `agent_coordination` - Inter-agent communication
- `oversoul_metrics` - System-wide metrics

## Deployment

### 1. Start the Flask Backend
```bash
cd /home/ubuntu/n8n_alliance_project
python3 main.py
```

The Flask application will start on `http://0.0.0.0:5000` and create the database automatically.

### 2. Start n8n Workflow Engine
```bash
cd /home/ubuntu/n8n_alliance_project
N8N_PORT=5678 n8n start
```

n8n will be available at `http://localhost:5678` for workflow management.

### 3. Import n8n Workflows
1. Access the n8n web interface at `http://localhost:5678`
2. Navigate to Workflows
3. Import the following workflow files from the `workflows/` directory:
   - `oversoul-orchestrator.json`
   - `sophia-wisdom-agent.json`
   - `abundance-finance-agent.json`
   - `guardian-legal-agent.json`

### 4. Configure Webhook URLs
Update the webhook URLs in each n8n workflow to point to your Flask backend:
- Base URL: `http://localhost:5000/api/n8n/webhooks/`
- Specific endpoints:
  - Task completion: `/task-completed`
  - Agent status: `/agent-status-update`
  - Coordination: `/coordination-update`
  - Harmony check: `/harmony-check-result`

### 5. Activate Workflows
Use the n8n interface or API to activate all imported workflows.

## API Documentation

### Health Check
```
GET /health
```
Returns system health status.

### DBA Management
```
GET /api/dba/entities
POST /api/dba/entities
```
Manage DBA entities and their performance metrics.

### Investment Management
```
GET /api/investments
POST /api/investments
PUT /api/investments/{id}/status
```
Track investments, funding rounds, and investor relations.

### Grant Management
```
GET /api/grants
POST /api/grants
```
Manage grant applications and funding opportunities.

### Agent Management
```
GET /api/agents
POST /api/agents
PUT /api/agents/{id}
PUT /api/agents/{id}/status
```
Configure and monitor the 13 agent types.

### Task Management
```
GET /api/tasks
POST /api/tasks
PUT /api/tasks/{id}
PUT /api/tasks/{id}/assign
```
Create, assign, and track tasks across agents.

### n8n Integration
```
GET /api/n8n/workflows/status
POST /api/n8n/workflows/activate
POST /api/n8n/workflows/trigger/{workflow_type}
POST /api/n8n/agents/{agent_id}/trigger
POST /api/n8n/tasks/{task_id}/trigger
```
Integrate with n8n workflows and trigger automation.

### Performance Monitoring
```
GET /api/agents/{id}/performance
POST /api/agents/{id}/performance
GET /api/oversoul/metrics
POST /api/oversoul/metrics
```
Monitor agent performance and system-wide metrics.

## n8n Workflow Setup

### Oversoul Orchestrator Workflow
**Purpose:** Central coordination and harmony monitoring  
**Triggers:** Hourly cron schedule  
**Key Functions:**
- DBA performance evaluation
- Resource allocation via Capacitor model
- Harmony score calculation
- Emergency alert system

### Sophia Wisdom Agent Workflow
**Purpose:** Wisdom processing and spiritual guidance  
**Triggers:** Webhook for queries, daily wisdom sharing  
**Key Functions:**
- Resonance analysis
- Living Archive integration
- Spiritual alignment assessment
- Daily wisdom broadcasting

### Abundance Finance Agent Workflow
**Purpose:** Financial management and prosperity tracking  
**Triggers:** 6-hour sync schedule, transaction webhooks  
**Key Functions:**
- DBA financial performance tracking
- Abundance metrics calculation
- Alert system for financial issues
- Investor reporting

### Guardian Legal Agent Workflow
**Purpose:** Legal compliance and contract management  
**Triggers:** Weekly compliance checks, contract request webhooks  
**Key Functions:**
- Compliance monitoring
- Contract lifecycle management
- Risk assessment
- Legal document generation

## Monitoring and Maintenance

### System Health Monitoring
1. **Health Check Endpoint**: Monitor `/health` for system status
2. **Database Monitoring**: Check database connectivity and performance
3. **n8n Workflow Status**: Monitor workflow execution and errors
4. **API Response Times**: Track endpoint performance

### Regular Maintenance Tasks
1. **Daily**: Review workflow execution logs
2. **Weekly**: Update agent performance metrics
3. **Monthly**: Database backup and optimization
4. **Quarterly**: Security audit and dependency updates

### Log Files
- Flask application logs: Check console output
- n8n workflow logs: Available in n8n interface
- Database logs: SQLite transaction logs

### Performance Metrics
Monitor the following key metrics:
- Agent response times
- Task completion rates
- Spiritual alignment scores
- Financial abundance metrics
- System harmony levels

## Troubleshooting

### Common Issues

#### Flask Application Won't Start
**Symptoms:** Import errors, database connection issues  
**Solutions:**
1. Verify all Python dependencies are installed
2. Check database directory permissions
3. Ensure no port conflicts on 5000

#### n8n Workflows Not Triggering
**Symptoms:** Workflows remain inactive, no execution logs  
**Solutions:**
1. Verify webhook URLs are correct
2. Check n8n workflow activation status
3. Test webhook endpoints manually

#### Database Connection Errors
**Symptoms:** SQLAlchemy errors, table not found  
**Solutions:**
1. Ensure database directory exists
2. Check file permissions
3. Restart Flask application to recreate tables

#### API Endpoints Returning 500 Errors
**Symptoms:** Internal server errors on API calls  
**Solutions:**
1. Check Flask application logs
2. Verify database schema matches models
3. Test with minimal data payloads

### Debug Mode
Enable debug mode for development:
```python
app.run(host='0.0.0.0', port=5000, debug=True)
```

### Testing API Endpoints
Use curl or Postman to test endpoints:
```bash
# Health check
curl http://localhost:5000/health

# Get DBA entities
curl http://localhost:5000/api/dba/entities

# Get agents
curl http://localhost:5000/api/agents
```

## Security Considerations

### Authentication and Authorization
- Implement API key authentication for production
- Use HTTPS for all external communications
- Secure webhook endpoints with validation

### Data Protection
- Encrypt sensitive data in database
- Implement data retention policies
- Regular security audits

### Network Security
- Use firewall rules to restrict access
- VPN access for administrative functions
- Monitor for unusual API activity

### Backup and Recovery
- Regular database backups
- Workflow configuration backups
- Disaster recovery procedures

## Production Deployment

### Recommended Production Setup
1. **Web Server**: Use Gunicorn or uWSGI instead of Flask dev server
2. **Reverse Proxy**: Nginx for SSL termination and load balancing
3. **Database**: PostgreSQL for production workloads
4. **Monitoring**: Prometheus and Grafana for metrics
5. **Logging**: Centralized logging with ELK stack

### Environment-Specific Configuration
- Development: SQLite, debug mode enabled
- Staging: PostgreSQL, limited debug logging
- Production: PostgreSQL, comprehensive monitoring

### Scaling Considerations
- Horizontal scaling with multiple Flask instances
- Database connection pooling
- Redis for session management and caching
- Load balancing for high availability

---

*This deployment guide ensures successful implementation of the 11:11 Alliance automation platform while maintaining spiritual alignment and operational excellence.*


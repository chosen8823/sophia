import requests
import json
from datetime import datetime
from typing import Dict, List, Optional
import os

class N8NIntegrationService:
    """Service for integrating with n8n workflow automation"""
    
    def __init__(self, n8n_base_url: str = None, api_key: str = None):
        self.base_url = n8n_base_url or os.getenv('N8N_BASE_URL', 'http://localhost:5678')
        self.api_key = api_key or os.getenv('N8N_API_KEY')
        self.headers = {
            'Content-Type': 'application/json'
        }
        if self.api_key:
            self.headers['Authorization'] = f'Bearer {self.api_key}'
    
    def trigger_workflow(self, workflow_id: str, data: Dict = None) -> Dict:
        """Trigger an n8n workflow with optional data"""
        url = f"{self.base_url}/webhook/{workflow_id}"
        
        try:
            response = requests.post(url, json=data or {}, headers=self.headers)
            response.raise_for_status()
            return {
                'success': True,
                'data': response.json() if response.content else {},
                'status_code': response.status_code
            }
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e),
                'status_code': getattr(e.response, 'status_code', None) if hasattr(e, 'response') else None
            }
    
    def get_workflow_executions(self, workflow_id: str, limit: int = 10) -> Dict:
        """Get recent executions of a workflow"""
        url = f"{self.base_url}/api/v1/executions"
        params = {
            'workflowId': workflow_id,
            'limit': limit
        }
        
        try:
            response = requests.get(url, params=params, headers=self.headers)
            response.raise_for_status()
            return {
                'success': True,
                'executions': response.json().get('data', [])
            }
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_workflow_status(self, workflow_id: str) -> Dict:
        """Get the status of a workflow"""
        url = f"{self.base_url}/api/v1/workflows/{workflow_id}"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            workflow_data = response.json()
            return {
                'success': True,
                'workflow': {
                    'id': workflow_data.get('id'),
                    'name': workflow_data.get('name'),
                    'active': workflow_data.get('active', False),
                    'nodes': len(workflow_data.get('nodes', [])),
                    'updated_at': workflow_data.get('updatedAt')
                }
            }
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def activate_workflow(self, workflow_id: str) -> Dict:
        """Activate a workflow"""
        url = f"{self.base_url}/api/v1/workflows/{workflow_id}/activate"
        
        try:
            response = requests.post(url, headers=self.headers)
            response.raise_for_status()
            return {
                'success': True,
                'message': 'Workflow activated successfully'
            }
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def deactivate_workflow(self, workflow_id: str) -> Dict:
        """Deactivate a workflow"""
        url = f"{self.base_url}/api/v1/workflows/{workflow_id}/deactivate"
        
        try:
            response = requests.post(url, headers=self.headers)
            response.raise_for_status()
            return {
                'success': True,
                'message': 'Workflow deactivated successfully'
            }
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e)
            }

class AgentWorkflowManager:
    """Manager for agent-specific workflow operations"""
    
    def __init__(self, n8n_service: N8NIntegrationService):
        self.n8n = n8n_service
        
        # Mapping of agent types to their n8n workflow IDs
        self.agent_workflows = {
            'oversoul_orchestrator': 'oversoul-orchestrator',
            'sophia_wisdom': 'sophia-wisdom-agent',
            'abundance_finance': 'abundance-finance-agent',
            'guardian_legal': 'guardian-legal-agent'
        }
    
    def trigger_agent_workflow(self, agent_type: str, agent_data: Dict) -> Dict:
        """Trigger a workflow for a specific agent type"""
        workflow_id = self.agent_workflows.get(agent_type)
        if not workflow_id:
            return {
                'success': False,
                'error': f'No workflow found for agent type: {agent_type}'
            }
        
        # Prepare data for the workflow
        workflow_data = {
            'agent': agent_data,
            'timestamp': datetime.utcnow().isoformat(),
            'trigger_source': 'operational_system'
        }
        
        return self.n8n.trigger_workflow(workflow_id, workflow_data)
    
    def trigger_task_workflow(self, task_data: Dict, agent_type: str) -> Dict:
        """Trigger a workflow for task execution"""
        workflow_id = self.agent_workflows.get(agent_type)
        if not workflow_id:
            return {
                'success': False,
                'error': f'No workflow found for agent type: {agent_type}'
            }
        
        # Prepare task data for the workflow
        workflow_data = {
            'task': task_data,
            'timestamp': datetime.utcnow().isoformat(),
            'action': 'execute_task'
        }
        
        return self.n8n.trigger_workflow(workflow_id, workflow_data)
    
    def trigger_coordination_workflow(self, coordination_data: Dict) -> Dict:
        """Trigger workflow for agent coordination"""
        # Use the oversoul orchestrator for coordination
        workflow_id = self.agent_workflows.get('oversoul_orchestrator')
        
        workflow_data = {
            'coordination': coordination_data,
            'timestamp': datetime.utcnow().isoformat(),
            'action': 'coordinate_agents'
        }
        
        return self.n8n.trigger_workflow(workflow_id, workflow_data)
    
    def trigger_performance_update(self, performance_data: Dict) -> Dict:
        """Trigger workflow for performance metric updates"""
        # Use the oversoul orchestrator for performance tracking
        workflow_id = self.agent_workflows.get('oversoul_orchestrator')
        
        workflow_data = {
            'performance': performance_data,
            'timestamp': datetime.utcnow().isoformat(),
            'action': 'update_performance'
        }
        
        return self.n8n.trigger_workflow(workflow_id, workflow_data)
    
    def get_all_workflow_statuses(self) -> Dict:
        """Get status of all agent workflows"""
        statuses = {}
        
        for agent_type, workflow_id in self.agent_workflows.items():
            status = self.n8n.get_workflow_status(workflow_id)
            statuses[agent_type] = status
        
        return statuses
    
    def activate_all_workflows(self) -> Dict:
        """Activate all agent workflows"""
        results = {}
        
        for agent_type, workflow_id in self.agent_workflows.items():
            result = self.n8n.activate_workflow(workflow_id)
            results[agent_type] = result
        
        return results

class OversoulOrchestrator:
    """High-level orchestrator for the entire system"""
    
    def __init__(self, workflow_manager: AgentWorkflowManager):
        self.workflow_manager = workflow_manager
    
    def trigger_system_harmony_check(self, system_data: Dict) -> Dict:
        """Trigger a system-wide harmony check"""
        return self.workflow_manager.trigger_agent_workflow('oversoul_orchestrator', {
            'action': 'harmony_check',
            'system_data': system_data,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def trigger_resource_allocation(self, allocation_data: Dict) -> Dict:
        """Trigger resource allocation workflow"""
        return self.workflow_manager.trigger_agent_workflow('oversoul_orchestrator', {
            'action': 'resource_allocation',
            'allocation_data': allocation_data,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def trigger_divine_alignment_check(self, alignment_data: Dict) -> Dict:
        """Trigger divine alignment assessment"""
        return self.workflow_manager.trigger_agent_workflow('sophia_wisdom', {
            'action': 'divine_alignment_check',
            'alignment_data': alignment_data,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def trigger_financial_abundance_flow(self, financial_data: Dict) -> Dict:
        """Trigger financial abundance flow assessment"""
        return self.workflow_manager.trigger_agent_workflow('abundance_finance', {
            'action': 'abundance_flow_check',
            'financial_data': financial_data,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def trigger_legal_compliance_check(self, compliance_data: Dict) -> Dict:
        """Trigger legal compliance assessment"""
        return self.workflow_manager.trigger_agent_workflow('guardian_legal', {
            'action': 'compliance_check',
            'compliance_data': compliance_data,
            'timestamp': datetime.utcnow().isoformat()
        })

# Utility functions for common operations
def create_n8n_service() -> N8NIntegrationService:
    """Create and return an n8n integration service instance"""
    return N8NIntegrationService()

def create_workflow_manager() -> AgentWorkflowManager:
    """Create and return a workflow manager instance"""
    n8n_service = create_n8n_service()
    return AgentWorkflowManager(n8n_service)

def create_oversoul_orchestrator() -> OversoulOrchestrator:
    """Create and return an oversoul orchestrator instance"""
    workflow_manager = create_workflow_manager()
    return OversoulOrchestrator(workflow_manager)


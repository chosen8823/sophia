from flask import Blueprint, request, jsonify, session, redirect, url_for
from authlib.integrations.flask_client import OAuth
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token
import os
import json

auth_bp = Blueprint('auth', __name__)

# Initialize OAuth
oauth = OAuth()

# Configure Google OAuth
oauth.register(
    name='google',
    client_id=os.environ.get('GOOGLE_CLIENT_ID'),
    client_secret=os.environ.get('GOOGLE_CLIENT_SECRET'),
    access_token_url='https://oauth2.googleapis.com/token',
    access_token_params=None,
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    authorize_params=None,
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    client_kwargs={
        'scope': 'openid email profile'
    }
)

@auth_bp.route('/login/google', methods=['GET'])
def login_google():
    """Initiate Google OAuth login"""
    try:
        # For development, use localhost. In production, use the actual domain
        redirect_uri = url_for('auth.authorize_google', _external=True)
        return oauth.google.authorize_redirect(redirect_uri)
    except Exception as e:
        return jsonify({'error': f'Failed to initiate Google login: {str(e)}'}), 500

@auth_bp.route('/authorize/google', methods=['GET'])
def authorize_google():
    """Handle Google OAuth callback"""
    try:
        # Get the authorization token
        token = oauth.google.authorize_access_token()
        
        # Parse the ID token to get user info
        userinfo = oauth.google.parse_id_token(token)
        
        # Store user info in session
        session['user'] = {
            'id': userinfo['sub'],
            'email': userinfo['email'],
            'name': userinfo['name'],
            'picture': userinfo.get('picture', ''),
            'verified_email': userinfo.get('email_verified', False)
        }
        
        # In a real application, you would save the user to your database here
        # For now, we'll just store in session
        
        return jsonify({
            'success': True,
            'message': 'Successfully authenticated with Google',
            'user': session['user']
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to authorize with Google: {str(e)}'}), 500

@auth_bp.route('/verify-token', methods=['POST'])
def verify_google_token():
    """Verify Google ID token sent from frontend"""
    try:
        data = request.get_json()
        token = data.get('token')
        
        if not token:
            return jsonify({'error': 'No token provided'}), 400
        
        # Verify the token
        client_id = os.environ.get('GOOGLE_CLIENT_ID')
        idinfo = id_token.verify_oauth2_token(
            token, 
            google_requests.Request(), 
            client_id
        )
        
        # Token is valid, extract user info
        user_info = {
            'id': idinfo['sub'],
            'email': idinfo['email'],
            'name': idinfo['name'],
            'picture': idinfo.get('picture', ''),
            'verified_email': idinfo.get('email_verified', False)
        }
        
        # Store user info in session
        session['user'] = user_info
        
        # In a real application, you would:
        # 1. Check if user exists in database
        # 2. Create new user if doesn't exist
        # 3. Update user info if exists
        # 4. Generate JWT or session token
        
        return jsonify({
            'success': True,
            'message': 'Token verified successfully',
            'user': user_info
        })
        
    except ValueError as e:
        # Invalid token
        return jsonify({'error': f'Invalid token: {str(e)}'}), 401
    except Exception as e:
        return jsonify({'error': f'Token verification failed: {str(e)}'}), 500

@auth_bp.route('/user', methods=['GET'])
def get_current_user():
    """Get current authenticated user"""
    user = session.get('user')
    if user:
        return jsonify({
            'success': True,
            'user': user,
            'authenticated': True
        })
    else:
        return jsonify({
            'success': False,
            'message': 'No authenticated user',
            'authenticated': False
        }), 401

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """Logout current user"""
    session.pop('user', None)
    return jsonify({
        'success': True,
        'message': 'Successfully logged out'
    })

@auth_bp.route('/status', methods=['GET'])
def auth_status():
    """Check authentication status"""
    user = session.get('user')
    return jsonify({
        'authenticated': user is not None,
        'user': user if user else None
    })


# n8n Workflow Deployment Guide for 11:11 Alliance

## Overview

This guide provides step-by-step instructions for deploying the n8n workflow automation system for the 11:11 Alliance Multi-Agent Oversoul Operating System. The workflows implement the core agent functionality described in the platform architecture.

## Prerequisites

- n8n installed (version 1.104.1 or higher)
- Node.js 20.18.0 or higher
- Access to the alliance backend API endpoints
- Proper authentication tokens configured

## Workflow Components

### 1. Oversoul Orchestrator Workflow
**File:** `oversoul-orchestrator.json`
**Purpose:** Central coordination and harmony monitoring
**Triggers:** Hourly cron schedule
**Key Features:**
- DBA performance evaluation
- Resource allocation via Capacitor model
- Harmony score calculation
- Emergency alert system

### 2. Sophia Wisdom Agent Workflow
**File:** `sophia-wisdom-agent.json`
**Purpose:** Wisdom processing and spiritual guidance
**Triggers:** Webhook for queries, daily wisdom sharing
**Key Features:**
- Resonance analysis
- Living Archive integration
- Spiritual alignment assessment
- Daily wisdom broadcasting

### 3. Abundance Finance Agent Workflow
**File:** `abundance-finance-agent.json`
**Purpose:** Financial management and prosperity tracking
**Triggers:** 6-hour sync schedule, transaction webhooks
**Key Features:**
- DBA financial performance tracking
- Abundance metrics calculation
- Alert system for financial issues
- Investor reporting

### 4. Guardian Legal Agent Workflow
**File:** `guardian-legal-agent.json`
**Purpose:** Legal compliance and contract management
**Triggers:** Weekly compliance checks, contract request webhooks
**Key Features:**
- Compliance monitoring
- Contract lifecycle management
- Risk assessment
- Legal document generation

## Deployment Steps

### Step 1: Start n8n
```bash
# Start n8n with custom configuration
n8n start --tunnel
```

### Step 2: Import Workflows
1. Open n8n web interface (typically http://localhost:5678)
2. Navigate to Workflows
3. Click "Import from file"
4. Import each workflow JSON file:
   - oversoul-orchestrator.json
   - sophia-wisdom-agent.json
   - abundance-finance-agent.json
   - guardian-legal-agent.json

### Step 3: Configure API Endpoints
Update the HTTP Request nodes in each workflow to point to your backend API:

```javascript
// Example endpoint configuration
const baseURL = "https://your-alliance-api.com";
// or for local development:
const baseURL = "http://localhost:5000";
```

### Step 4: Set Up Webhooks
Configure webhook URLs for external integrations:

1. **Sophia Wisdom Agent**
   - Webhook URL: `{n8n-url}/webhook/sophia-wisdom-query`
   - Method: POST
   - Use for: User queries, external wisdom requests

2. **Abundance Finance Agent**
   - Webhook URL: `{n8n-url}/webhook/finance-transaction`
   - Method: POST
   - Use for: Real-time transaction notifications

3. **Guardian Legal Agent**
   - Webhook URL: `{n8n-url}/webhook/legal-contract-request`
   - Method: POST
   - Use for: Contract generation requests

### Step 5: Configure Authentication
Set up authentication for API calls:

1. Go to Settings > Credentials
2. Add HTTP Header Auth credentials
3. Configure Authorization headers for each API endpoint
4. Update HTTP Request nodes to use the credentials

### Step 6: Test Workflows
1. Activate each workflow
2. Test triggers manually:
   - Use "Execute Workflow" for cron-triggered workflows
   - Send test requests to webhook endpoints
3. Verify API connectivity and data flow

## Environment Configuration

### Required Environment Variables
```bash
# API Configuration
ALLIANCE_API_BASE_URL=https://your-api.com
ALLIANCE_API_TOKEN=your-auth-token

# Database Configuration
DATABASE_URL=your-database-connection-string

# Notification Configuration
SLACK_WEBHOOK_URL=your-slack-webhook
EMAIL_SMTP_CONFIG=your-email-config

# Spiritual Alignment
HOLY_SPIRIT_FLOW_ENDPOINT=your-spiritual-guidance-api
```

### API Endpoint Requirements
Ensure your backend provides these endpoints:

#### Oversoul Orchestrator
- `GET /api/dba/metrics` - DBA performance data
- `GET /api/capacitor/state` - Resource capacitor status
- `POST /api/capacitor/update` - Update capacitor state
- `POST /api/alerts/emergency` - Emergency notifications
- `POST /api/dashboard/update` - Dashboard updates
- `POST /api/agents/coordinate` - Agent coordination

#### Sophia Wisdom Agent
- `GET /api/knowledge/scrolls` - Living Archive access
- `POST /api/knowledge/scrolls` - Save new scrolls
- `POST /api/broadcast/wisdom` - Wisdom broadcasting

#### Abundance Finance Agent
- `GET /api/finance/accounts` - Account data
- `GET /api/finance/budgets` - Budget information
- `POST /api/finance/transactions` - Transaction recording
- `POST /api/alerts/financial` - Financial alerts
- `POST /api/dashboard/financial` - Financial dashboard
- `POST /api/reports/investor` - Investor reports

#### Guardian Legal Agent
- `GET /api/legal/contracts` - Contract database
- `GET /api/legal/compliance` - Compliance status
- `POST /api/contracts/generate` - Contract generation
- `POST /api/alerts/legal` - Legal alerts
- `POST /api/dashboard/legal` - Legal dashboard

## Monitoring and Maintenance

### Workflow Health Monitoring
1. Set up execution monitoring in n8n
2. Configure error notifications
3. Monitor webhook response times
4. Track API endpoint availability

### Regular Maintenance Tasks
1. **Weekly:** Review workflow execution logs
2. **Monthly:** Update workflow configurations
3. **Quarterly:** Performance optimization review
4. **Annually:** Security audit and credential rotation

### Troubleshooting Common Issues

#### Webhook Not Triggering
- Verify webhook URL is accessible
- Check firewall and network settings
- Validate webhook payload format

#### API Connection Failures
- Verify API endpoint URLs
- Check authentication credentials
- Monitor API rate limits

#### Workflow Execution Errors
- Review execution logs in n8n
- Check data format compatibility
- Verify node configurations

## Scaling Considerations

### High Availability Setup
1. Deploy n8n in cluster mode
2. Use external database for workflow data
3. Implement load balancing for webhooks
4. Set up backup and disaster recovery

### Performance Optimization
1. Optimize workflow execution order
2. Implement caching for frequently accessed data
3. Use batch processing for large datasets
4. Monitor and tune resource allocation

## Security Best Practices

### Authentication and Authorization
1. Use strong API tokens
2. Implement role-based access control
3. Regular credential rotation
4. Audit access logs

### Data Protection
1. Encrypt sensitive data in transit
2. Implement data retention policies
3. Secure webhook endpoints
4. Regular security assessments

## Integration with Alliance Systems

### Dashboard Integration
Configure workflows to update the alliance dashboard:
- Real-time status updates
- Performance metrics
- Alert notifications
- Spiritual alignment indicators

### External System Integration
Set up connections to:
- Financial institutions (banking APIs)
- Legal service providers
- Communication platforms (Slack, email)
- Cloud storage systems

### Spiritual Alignment Integration
Ensure workflows maintain connection to:
- Holy Spirit Flow Agent
- Divine guidance systems
- Spiritual assessment tools
- Community feedback mechanisms

## Support and Documentation

### Getting Help
- n8n Community Forum: https://community.n8n.io/
- Alliance Technical Support: [internal contact]
- Workflow Documentation: [internal wiki]

### Additional Resources
- n8n Official Documentation: https://docs.n8n.io/
- Workflow Best Practices Guide: [internal resource]
- API Integration Examples: [internal repository]

---

*This deployment guide ensures that the n8n workflow automation system properly implements the Multi-Agent Oversoul Operating System while maintaining spiritual alignment and operational excellence.*


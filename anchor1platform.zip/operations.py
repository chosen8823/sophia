from flask import Blueprint, request, jsonify
from datetime import datetime, date
import json
from src.models.investment import db, DBAEntity
from src.models.user import User

# Import operational models from the extracted content
import sys
import os
sys.path.append('/home/ubuntu/upload/extracted_content')

try:
    from operational_roles import (
        Agent, Task, AgentPerformanceMetric, AgentCoordination, 
        OversoulMetrics, AgentType, AgentStatus, TaskStatus, TaskPriority
    )
    from n8n_integration import (
        N8NIntegrationService, AgentWorkflowManager, OversoulOrchestrator,
        create_n8n_service, create_workflow_manager, create_oversoul_orchestrator
    )
except ImportError:
    # Fallback if imports fail
    Agent = Task = AgentPerformanceMetric = AgentCoordination = OversoulMetrics = None
    N8NIntegrationService = AgentWorkflowManager = OversoulOrchestrator = None

operations_bp = Blueprint('operations', __name__)

# Initialize n8n integration services
try:
    n8n_service = create_n8n_service()
    workflow_manager = create_workflow_manager()
    oversoul_orchestrator = create_oversoul_orchestrator()
except:
    n8n_service = workflow_manager = oversoul_orchestrator = None

# Agent Management Endpoints
@operations_bp.route('/agents', methods=['GET'])
def get_agents():
    """Get all agents with their current status"""
    if not Agent:
        return jsonify({'error': 'Agent model not available'}), 500
    
    dba_id = request.args.get('dba_id', type=int)
    agent_type = request.args.get('type')
    status = request.args.get('status')
    
    query = Agent.query
    
    if dba_id:
        query = query.filter_by(dba_id=dba_id)
    if agent_type:
        query = query.filter_by(agent_type=AgentType(agent_type))
    if status:
        query = query.filter_by(status=AgentStatus(status))
    
    agents = query.all()
    result = [agent.to_dict() for agent in agents]
    
    return jsonify(result)

@operations_bp.route('/agents', methods=['POST'])
def create_agent():
    """Create a new agent"""
    if not Agent:
        return jsonify({'error': 'Agent model not available'}), 500
    
    data = request.get_json()
    
    agent = Agent(
        name=data['name'],
        agent_type=AgentType(data['agent_type']),
        dba_id=data.get('dba_id'),
        description=data.get('description'),
        capabilities=json.dumps(data.get('capabilities', [])),
        configuration=json.dumps(data.get('configuration', {})),
        n8n_workflow_id=data.get('n8n_workflow_id'),
        spiritual_alignment_score=data.get('spiritual_alignment_score', 0.0)
    )
    
    db.session.add(agent)
    db.session.commit()
    
    # Trigger n8n workflow activation if workflow_id provided
    if agent.n8n_workflow_id and n8n_service:
        try:
            activation_result = n8n_service.activate_workflow(agent.n8n_workflow_id)
            if not activation_result.get('success'):
                print(f"Warning: Failed to activate workflow {agent.n8n_workflow_id}")
        except Exception as e:
            print(f"Error activating workflow: {e}")
    
    return jsonify({'id': agent.id, 'message': 'Agent created successfully'}), 201

@operations_bp.route('/agents/<int:agent_id>', methods=['PUT'])
def update_agent():
    """Update an agent"""
    if not Agent:
        return jsonify({'error': 'Agent model not available'}), 500
    
    agent = Agent.query.get_or_404(agent_id)
    data = request.get_json()
    
    # Update agent fields
    if 'name' in data:
        agent.name = data['name']
    if 'status' in data:
        agent.status = AgentStatus(data['status'])
    if 'description' in data:
        agent.description = data['description']
    if 'capabilities' in data:
        agent.capabilities = json.dumps(data['capabilities'])
    if 'configuration' in data:
        agent.configuration = json.dumps(data['configuration'])
    if 'spiritual_alignment_score' in data:
        agent.spiritual_alignment_score = data['spiritual_alignment_score']
    if 'performance_score' in data:
        agent.performance_score = data['performance_score']
    
    agent.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({'message': 'Agent updated successfully'})

@operations_bp.route('/agents/<int:agent_id>/activate', methods=['POST'])
def activate_agent():
    """Activate an agent and its workflow"""
    if not Agent:
        return jsonify({'error': 'Agent model not available'}), 500
    
    agent = Agent.query.get_or_404(agent_id)
    agent.status = AgentStatus.ACTIVE
    agent.last_activity = datetime.utcnow()
    db.session.commit()
    
    # Activate n8n workflow if available
    if agent.n8n_workflow_id and n8n_service:
        try:
            result = n8n_service.activate_workflow(agent.n8n_workflow_id)
            return jsonify({
                'message': 'Agent activated successfully',
                'workflow_activation': result
            })
        except Exception as e:
            return jsonify({
                'message': 'Agent activated but workflow activation failed',
                'error': str(e)
            }), 207
    
    return jsonify({'message': 'Agent activated successfully'})

# Task Management Endpoints
@operations_bp.route('/tasks', methods=['GET'])
def get_tasks():
    """Get tasks with filtering options"""
    if not Task:
        return jsonify({'error': 'Task model not available'}), 500
    
    agent_id = request.args.get('agent_id', type=int)
    dba_id = request.args.get('dba_id', type=int)
    status = request.args.get('status')
    priority = request.args.get('priority')
    
    query = Task.query
    
    if agent_id:
        query = query.filter_by(agent_id=agent_id)
    if dba_id:
        query = query.filter_by(dba_id=dba_id)
    if status:
        query = query.filter_by(status=TaskStatus(status))
    if priority:
        query = query.filter_by(priority=TaskPriority(priority))
    
    tasks = query.order_by(Task.created_at.desc()).all()
    result = [task.to_dict() for task in tasks]
    
    return jsonify(result)

@operations_bp.route('/tasks', methods=['POST'])
def create_task():
    """Create a new task"""
    if not Task:
        return jsonify({'error': 'Task model not available'}), 500
    
    data = request.get_json()
    
    task = Task(
        title=data['title'],
        description=data.get('description'),
        agent_id=data['agent_id'],
        dba_id=data.get('dba_id'),
        priority=TaskPriority(data.get('priority', 'medium')),
        due_date=datetime.strptime(data['due_date'], '%Y-%m-%d %H:%M:%S') if data.get('due_date') else None,
        estimated_hours=data.get('estimated_hours'),
        dependencies=json.dumps(data.get('dependencies', [])),
        task_metadata=json.dumps(data.get('metadata', {})),
        spiritual_alignment_notes=data.get('spiritual_alignment_notes')
    )
    
    db.session.add(task)
    db.session.commit()
    
    # Trigger n8n workflow for task assignment
    if workflow_manager:
        try:
            agent = Agent.query.get(task.agent_id)
            if agent and agent.agent_type:
                workflow_result = workflow_manager.trigger_task_workflow(
                    task.to_dict(), 
                    agent.agent_type.value
                )
                if not workflow_result.get('success'):
                    print(f"Warning: Failed to trigger workflow for task {task.id}")
        except Exception as e:
            print(f"Error triggering task workflow: {e}")
    
    return jsonify({'id': task.id, 'message': 'Task created successfully'}), 201

@operations_bp.route('/tasks/<int:task_id>/status', methods=['PUT'])
def update_task_status():
    """Update task status"""
    if not Task:
        return jsonify({'error': 'Task model not available'}), 500
    
    task = Task.query.get_or_404(task_id)
    data = request.get_json()
    
    old_status = task.status
    new_status = TaskStatus(data['status'])
    
    task.status = new_status
    task.progress_percentage = data.get('progress_percentage', task.progress_percentage)
    
    # Update timestamps based on status
    if new_status == TaskStatus.IN_PROGRESS and old_status == TaskStatus.PENDING:
        task.started_at = datetime.utcnow()
    elif new_status == TaskStatus.COMPLETED:
        task.completed_at = datetime.utcnow()
        if 'actual_hours' in data:
            task.actual_hours = data['actual_hours']
    
    task.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({'message': 'Task status updated successfully'})

# Performance Metrics Endpoints
@operations_bp.route('/performance/agents/<int:agent_id>', methods=['GET'])
def get_agent_performance():
    """Get performance metrics for an agent"""
    if not AgentPerformanceMetric:
        return jsonify({'error': 'Performance model not available'}), 500
    
    days = request.args.get('days', 30, type=int)
    
    metrics = AgentPerformanceMetric.query.filter_by(agent_id=agent_id)\
        .filter(AgentPerformanceMetric.measurement_date >= date.today() - timedelta(days=days))\
        .order_by(AgentPerformanceMetric.measurement_date.desc()).all()
    
    result = [metric.to_dict() for metric in metrics]
    
    return jsonify(result)

@operations_bp.route('/performance/agents/<int:agent_id>', methods=['POST'])
def record_agent_performance():
    """Record performance metrics for an agent"""
    if not AgentPerformanceMetric:
        return jsonify({'error': 'Performance model not available'}), 500
    
    data = request.get_json()
    
    metric = AgentPerformanceMetric(
        agent_id=agent_id,
        measurement_date=datetime.strptime(data['measurement_date'], '%Y-%m-%d').date(),
        tasks_completed=data.get('tasks_completed', 0),
        tasks_failed=data.get('tasks_failed', 0),
        average_completion_time=data.get('average_completion_time'),
        quality_score=data.get('quality_score', 0.0),
        efficiency_score=data.get('efficiency_score', 0.0),
        spiritual_alignment_score=data.get('spiritual_alignment_score', 0.0),
        user_satisfaction_score=data.get('user_satisfaction_score', 0.0),
        error_rate=data.get('error_rate', 0.0),
        uptime_percentage=data.get('uptime_percentage', 100.0),
        notes=data.get('notes')
    )
    
    db.session.add(metric)
    db.session.commit()
    
    # Trigger performance update workflow
    if workflow_manager:
        try:
            workflow_result = workflow_manager.trigger_performance_update(metric.to_dict())
            if not workflow_result.get('success'):
                print(f"Warning: Failed to trigger performance update workflow")
        except Exception as e:
            print(f"Error triggering performance workflow: {e}")
    
    return jsonify({'id': metric.id, 'message': 'Performance metrics recorded successfully'}), 201

# Agent Coordination Endpoints
@operations_bp.route('/coordination', methods=['GET'])
def get_coordination_events():
    """Get agent coordination events"""
    if not AgentCoordination:
        return jsonify({'error': 'Coordination model not available'}), 500
    
    agent_id = request.args.get('agent_id', type=int)
    status = request.args.get('status')
    
    query = AgentCoordination.query
    
    if agent_id:
        query = query.filter(
            (AgentCoordination.primary_agent_id == agent_id) | 
            (AgentCoordination.secondary_agent_id == agent_id)
        )
    if status:
        query = query.filter_by(status=status)
    
    events = query.order_by(AgentCoordination.created_at.desc()).all()
    result = [event.to_dict() for event in events]
    
    return jsonify(result)

@operations_bp.route('/coordination', methods=['POST'])
def create_coordination_event():
    """Create a new agent coordination event"""
    if not AgentCoordination:
        return jsonify({'error': 'Coordination model not available'}), 500
    
    data = request.get_json()
    
    coordination = AgentCoordination(
        primary_agent_id=data['primary_agent_id'],
        secondary_agent_id=data['secondary_agent_id'],
        coordination_type=data['coordination_type'],
        task_id=data.get('task_id'),
        message=data.get('message'),
        status='pending'
    )
    
    db.session.add(coordination)
    db.session.commit()
    
    # Trigger coordination workflow
    if workflow_manager:
        try:
            workflow_result = workflow_manager.trigger_coordination_workflow(coordination.to_dict())
            if not workflow_result.get('success'):
                print(f"Warning: Failed to trigger coordination workflow")
        except Exception as e:
            print(f"Error triggering coordination workflow: {e}")
    
    return jsonify({'id': coordination.id, 'message': 'Coordination event created successfully'}), 201

# Oversoul Metrics Endpoints
@operations_bp.route('/oversoul/metrics', methods=['GET'])
def get_oversoul_metrics():
    """Get oversoul system metrics"""
    if not OversoulMetrics:
        return jsonify({'error': 'Oversoul metrics model not available'}), 500
    
    days = request.args.get('days', 30, type=int)
    
    metrics = OversoulMetrics.query\
        .filter(OversoulMetrics.measurement_date >= date.today() - timedelta(days=days))\
        .order_by(OversoulMetrics.measurement_date.desc()).all()
    
    result = [metric.to_dict() for metric in metrics]
    
    return jsonify(result)

@operations_bp.route('/oversoul/metrics', methods=['POST'])
def record_oversoul_metrics():
    """Record oversoul system metrics"""
    if not OversoulMetrics:
        return jsonify({'error': 'Oversoul metrics model not available'}), 500
    
    data = request.get_json()
    
    metric = OversoulMetrics(
        measurement_date=datetime.strptime(data['measurement_date'], '%Y-%m-%d').date(),
        harmony_score=data.get('harmony_score', 0.0),
        collective_consciousness_level=data.get('collective_consciousness_level', 0.0),
        divine_alignment_score=data.get('divine_alignment_score', 0.0),
        resource_utilization_efficiency=data.get('resource_utilization_efficiency', 0.0),
        agent_coordination_score=data.get('agent_coordination_score', 0.0),
        system_resilience_score=data.get('system_resilience_score', 0.0),
        spiritual_flow_intensity=data.get('spiritual_flow_intensity', 0.0),
        total_active_agents=data.get('total_active_agents', 0),
        total_completed_tasks=data.get('total_completed_tasks', 0),
        average_task_completion_time=data.get('average_task_completion_time', 0.0),
        system_errors_count=data.get('system_errors_count', 0),
        notes=data.get('notes')
    )
    
    db.session.add(metric)
    db.session.commit()
    
    return jsonify({'id': metric.id, 'message': 'Oversoul metrics recorded successfully'}), 201

# N8N Integration Endpoints
@operations_bp.route('/n8n/workflows/status', methods=['GET'])
def get_workflow_statuses():
    """Get status of all n8n workflows"""
    if not workflow_manager:
        return jsonify({'error': 'N8N integration not available'}), 500
    
    try:
        statuses = workflow_manager.get_all_workflow_statuses()
        return jsonify(statuses)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@operations_bp.route('/n8n/workflows/activate', methods=['POST'])
def activate_all_workflows():
    """Activate all agent workflows"""
    if not workflow_manager:
        return jsonify({'error': 'N8N integration not available'}), 500
    
    try:
        results = workflow_manager.activate_all_workflows()
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@operations_bp.route('/n8n/trigger/harmony-check', methods=['POST'])
def trigger_harmony_check():
    """Trigger system harmony check"""
    if not oversoul_orchestrator:
        return jsonify({'error': 'Oversoul orchestrator not available'}), 500
    
    data = request.get_json()
    
    try:
        result = oversoul_orchestrator.trigger_system_harmony_check(data)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@operations_bp.route('/n8n/trigger/resource-allocation', methods=['POST'])
def trigger_resource_allocation():
    """Trigger resource allocation workflow"""
    if not oversoul_orchestrator:
        return jsonify({'error': 'Oversoul orchestrator not available'}), 500
    
    data = request.get_json()
    
    try:
        result = oversoul_orchestrator.trigger_resource_allocation(data)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Dashboard endpoints for operational overview
@operations_bp.route('/dashboard/overview', methods=['GET'])
def get_operations_overview():
    """Get operational dashboard overview"""
    try:
        overview = {
            'timestamp': datetime.utcnow().isoformat(),
            'agents': {
                'total': Agent.query.count() if Agent else 0,
                'active': Agent.query.filter_by(status=AgentStatus.ACTIVE).count() if Agent else 0,
                'inactive': Agent.query.filter_by(status=AgentStatus.INACTIVE).count() if Agent else 0,
                'error': Agent.query.filter_by(status=AgentStatus.ERROR).count() if Agent else 0
            },
            'tasks': {
                'total': Task.query.count() if Task else 0,
                'pending': Task.query.filter_by(status=TaskStatus.PENDING).count() if Task else 0,
                'in_progress': Task.query.filter_by(status=TaskStatus.IN_PROGRESS).count() if Task else 0,
                'completed': Task.query.filter_by(status=TaskStatus.COMPLETED).count() if Task else 0,
                'failed': Task.query.filter_by(status=TaskStatus.FAILED).count() if Task else 0
            },
            'system_health': {
                'overall_status': 'operational',
                'n8n_integration': 'available' if n8n_service else 'unavailable',
                'database_status': 'connected'
            }
        }
        
        # Add latest oversoul metrics if available
        if OversoulMetrics:
            latest_metric = OversoulMetrics.query.order_by(OversoulMetrics.measurement_date.desc()).first()
            if latest_metric:
                overview['oversoul_metrics'] = {
                    'harmony_score': latest_metric.harmony_score,
                    'divine_alignment_score': latest_metric.divine_alignment_score,
                    'spiritual_flow_intensity': latest_metric.spiritual_flow_intensity,
                    'measurement_date': latest_metric.measurement_date.isoformat()
                }
        
        return jsonify(overview)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Health check endpoint
@operations_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint for operations system"""
    try:
        health_status = {
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'components': {
                'database': 'connected',
                'n8n_integration': 'available' if n8n_service else 'unavailable',
                'operational_models': 'available' if Agent else 'unavailable'
            }
        }
        
        # Test database connection
        try:
            db.session.execute('SELECT 1')
            health_status['components']['database'] = 'connected'
        except:
            health_status['components']['database'] = 'disconnected'
            health_status['status'] = 'degraded'
        
        return jsonify(health_status)
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


from flask import Blueprint, request, jsonify
from datetime import datetime, date
import json
from src.models.investment import (
    db, DBAEntity, Investor, Investment, InvestmentMilestone, 
    InvestmentReturn, FinancialAccount, Transaction, Grant, 
    GrantReport, InvestorCommunication, AbundanceMetrics,
    InvestmentType, InvestmentStatus
)

funding_bp = Blueprint('funding', __name__)

# DBA Entity Management
@funding_bp.route('/dba/entities', methods=['GET'])
def get_dba_entities():
    """Get all DBA entities with their financial performance"""
    entities = DBAEntity.query.all()
    result = []
    
    for entity in entities:
        # Calculate current performance metrics
        latest_metrics = AbundanceMetrics.query.filter_by(dba_id=entity.id).order_by(AbundanceMetrics.measurement_date.desc()).first()
        
        entity_data = {
            'id': entity.id,
            'name': entity.name,
            'entity_type': entity.entity_type,
            'jurisdiction': entity.jurisdiction,
            'description': entity.description,
            'monthly_target': entity.monthly_target,
            'annual_target': entity.annual_target,
            'spiritual_mission': entity.spiritual_mission,
            'performance': {
                'abundance_score': latest_metrics.abundance_score if latest_metrics else 0,
                'divine_alignment_score': latest_metrics.divine_alignment_score if latest_metrics else 0,
                'prosperity_flow_status': latest_metrics.prosperity_flow_status if latest_metrics else 'unknown',
                'sustainability_rating': latest_metrics.sustainability_rating if latest_metrics else 'unknown'
            } if latest_metrics else None,
            'total_investments': sum([inv.amount for inv in entity.investments if inv.status == InvestmentStatus.FUNDED]),
            'active_grants': len([g for g in Grant.query.filter_by(dba_id=entity.id).all() if g.status == 'awarded'])
        }
        result.append(entity_data)
    
    return jsonify(result)

@funding_bp.route('/dba/entities', methods=['POST'])
def create_dba_entity():
    """Create a new DBA entity"""
    data = request.get_json()
    
    entity = DBAEntity(
        name=data['name'],
        entity_type=data['entity_type'],
        jurisdiction=data['jurisdiction'],
        ein=data.get('ein'),
        description=data.get('description'),
        monthly_target=data.get('monthly_target', 0),
        annual_target=data.get('annual_target', 0),
        spiritual_mission=data.get('spiritual_mission')
    )
    
    db.session.add(entity)
    db.session.commit()
    
    return jsonify({'id': entity.id, 'message': 'DBA entity created successfully'}), 201

# Investment Management
@funding_bp.route('/investments', methods=['GET'])
def get_investments():
    """Get all investments with filtering options"""
    dba_id = request.args.get('dba_id', type=int)
    investor_id = request.args.get('investor_id', type=int)
    status = request.args.get('status')
    investment_type = request.args.get('type')
    
    query = Investment.query
    
    if dba_id:
        query = query.filter_by(dba_id=dba_id)
    if investor_id:
        query = query.filter_by(investor_id=investor_id)
    if status:
        query = query.filter_by(status=InvestmentStatus(status))
    if investment_type:
        query = query.filter_by(investment_type=InvestmentType(investment_type))
    
    investments = query.all()
    result = []
    
    for inv in investments:
        investment_data = {
            'id': inv.id,
            'dba_name': inv.dba_entity.name,
            'investor_name': inv.investor.name,
            'investment_type': inv.investment_type.value,
            'status': inv.status.value,
            'amount': inv.amount,
            'currency': inv.currency,
            'equity_percentage': inv.equity_percentage,
            'interest_rate': inv.interest_rate,
            'term_months': inv.term_months,
            'funding_date': inv.funding_date.isoformat() if inv.funding_date else None,
            'maturity_date': inv.maturity_date.isoformat() if inv.maturity_date else None,
            'spiritual_alignment_notes': inv.spiritual_alignment_notes,
            'due_diligence_completed': inv.due_diligence_completed,
            'legal_documents_signed': inv.legal_documents_signed,
            'created_at': inv.created_at.isoformat()
        }
        result.append(investment_data)
    
    return jsonify(result)

@funding_bp.route('/investments', methods=['POST'])
def create_investment():
    """Create a new investment opportunity"""
    data = request.get_json()
    
    investment = Investment(
        dba_id=data['dba_id'],
        investor_id=data['investor_id'],
        investment_type=InvestmentType(data['investment_type']),
        amount=data['amount'],
        currency=data.get('currency', 'USD'),
        valuation_pre_money=data.get('valuation_pre_money'),
        equity_percentage=data.get('equity_percentage'),
        interest_rate=data.get('interest_rate'),
        term_months=data.get('term_months'),
        spiritual_alignment_notes=data.get('spiritual_alignment_notes'),
        terms_and_conditions=data.get('terms_and_conditions')
    )
    
    db.session.add(investment)
    db.session.commit()
    
    return jsonify({'id': investment.id, 'message': 'Investment created successfully'}), 201

@funding_bp.route('/investments/<int:investment_id>/status', methods=['PUT'])
def update_investment_status():
    """Update investment status"""
    investment = Investment.query.get_or_404(investment_id)
    data = request.get_json()
    
    investment.status = InvestmentStatus(data['status'])
    
    if data['status'] == 'funded' and not investment.funding_date:
        investment.funding_date = date.today()
    
    db.session.commit()
    
    return jsonify({'message': 'Investment status updated successfully'})

# Investor Management
@funding_bp.route('/investors', methods=['GET'])
def get_investors():
    """Get all investors"""
    investors = Investor.query.all()
    result = []
    
    for investor in investors:
        investor_data = {
            'id': investor.id,
            'name': investor.name,
            'email': investor.email,
            'phone': investor.phone,
            'investor_type': investor.investor_type,
            'accredited_status': investor.accredited_status,
            'spiritual_alignment_score': investor.spiritual_alignment_score,
            'total_invested': investor.total_invested,
            'preferred_investment_types': json.loads(investor.preferred_investment_types) if investor.preferred_investment_types else [],
            'active_investments': len([inv for inv in investor.investments if inv.status in [InvestmentStatus.FUNDED, InvestmentStatus.ACTIVE]]),
            'created_at': investor.created_at.isoformat()
        }
        result.append(investor_data)
    
    return jsonify(result)

@funding_bp.route('/investors', methods=['POST'])
def create_investor():
    """Create a new investor"""
    data = request.get_json()
    
    investor = Investor(
        name=data['name'],
        email=data['email'],
        phone=data.get('phone'),
        investor_type=data['investor_type'],
        accredited_status=data.get('accredited_status', False),
        spiritual_alignment_score=data.get('spiritual_alignment_score', 0),
        preferred_investment_types=json.dumps(data.get('preferred_investment_types', [])),
        communication_preferences=json.dumps(data.get('communication_preferences', {}))
    )
    
    db.session.add(investor)
    db.session.commit()
    
    return jsonify({'id': investor.id, 'message': 'Investor created successfully'}), 201

# Grant Management
@funding_bp.route('/grants', methods=['GET'])
def get_grants():
    """Get all grants with filtering"""
    dba_id = request.args.get('dba_id', type=int)
    status = request.args.get('status')
    
    query = Grant.query
    
    if dba_id:
        query = query.filter_by(dba_id=dba_id)
    if status:
        query = query.filter_by(status=status)
    
    grants = query.all()
    result = []
    
    for grant in grants:
        grant_data = {
            'id': grant.id,
            'dba_name': grant.dba_entity.name,
            'grant_name': grant.grant_name,
            'grantor_organization': grant.grantor_organization,
            'grant_type': grant.grant_type,
            'amount_requested': grant.amount_requested,
            'amount_awarded': grant.amount_awarded,
            'status': grant.status,
            'application_deadline': grant.application_deadline.isoformat() if grant.application_deadline else None,
            'award_date': grant.award_date.isoformat() if grant.award_date else None,
            'project_start_date': grant.project_start_date.isoformat() if grant.project_start_date else None,
            'project_end_date': grant.project_end_date.isoformat() if grant.project_end_date else None,
            'spiritual_mission_alignment': grant.spiritual_mission_alignment,
            'project_description': grant.project_description,
            'created_at': grant.created_at.isoformat()
        }
        result.append(grant_data)
    
    return jsonify(result)

@funding_bp.route('/grants', methods=['POST'])
def create_grant():
    """Create a new grant opportunity"""
    data = request.get_json()
    
    grant = Grant(
        dba_id=data['dba_id'],
        grant_name=data['grant_name'],
        grantor_organization=data['grantor_organization'],
        grant_type=data.get('grant_type'),
        amount_requested=data['amount_requested'],
        application_deadline=datetime.strptime(data['application_deadline'], '%Y-%m-%d').date() if data.get('application_deadline') else None,
        spiritual_mission_alignment=data.get('spiritual_mission_alignment'),
        project_description=data.get('project_description'),
        success_metrics=json.dumps(data.get('success_metrics', {}))
    )
    
    db.session.add(grant)
    db.session.commit()
    
    return jsonify({'id': grant.id, 'message': 'Grant opportunity created successfully'}), 201

# Financial Analytics
@funding_bp.route('/analytics/abundance', methods=['GET'])
def get_abundance_analytics():
    """Get abundance and prosperity analytics"""
    dba_id = request.args.get('dba_id', type=int)
    
    query = AbundanceMetrics.query
    if dba_id:
        query = query.filter_by(dba_id=dba_id)
    
    metrics = query.order_by(AbundanceMetrics.measurement_date.desc()).limit(30).all()
    
    result = {
        'overall_abundance_score': sum([m.abundance_score for m in metrics]) / len(metrics) if metrics else 0,
        'overall_divine_alignment': sum([m.divine_alignment_score for m in metrics]) / len(metrics) if metrics else 0,
        'total_generosity_capacity': sum([m.generosity_capacity for m in metrics]),
        'dba_performance': []
    }
    
    # Group by DBA
    dba_metrics = {}
    for metric in metrics:
        if metric.dba_id not in dba_metrics:
            dba_metrics[metric.dba_id] = []
        dba_metrics[metric.dba_id].append(metric)
    
    for dba_id, dba_metric_list in dba_metrics.items():
        latest_metric = dba_metric_list[0]  # Most recent
        dba_entity = DBAEntity.query.get(dba_id)
        
        dba_performance = {
            'dba_id': dba_id,
            'dba_name': dba_entity.name,
            'abundance_score': latest_metric.abundance_score,
            'divine_alignment_score': latest_metric.divine_alignment_score,
            'prosperity_flow_status': latest_metric.prosperity_flow_status,
            'sustainability_rating': latest_metric.sustainability_rating,
            'stewardship_score': latest_metric.stewardship_score,
            'revenue_current_month': latest_metric.revenue_current_month,
            'revenue_projected_annual': latest_metric.revenue_projected_annual,
            'target_achievement': (latest_metric.revenue_projected_annual / dba_entity.annual_target * 100) if dba_entity.annual_target > 0 else 0
        }
        result['dba_performance'].append(dba_performance)
    
    return jsonify(result)

@funding_bp.route('/analytics/abundance', methods=['POST'])
def record_abundance_metrics():
    """Record new abundance metrics"""
    data = request.get_json()
    
    metrics = AbundanceMetrics(
        dba_id=data['dba_id'],
        measurement_date=datetime.strptime(data['measurement_date'], '%Y-%m-%d').date(),
        revenue_current_month=data.get('revenue_current_month', 0),
        revenue_projected_annual=data.get('revenue_projected_annual', 0),
        abundance_score=data.get('abundance_score', 0),
        divine_alignment_score=data.get('divine_alignment_score', 0),
        prosperity_flow_status=data.get('prosperity_flow_status'),
        generosity_capacity=data.get('generosity_capacity', 0),
        sustainability_rating=data.get('sustainability_rating'),
        stewardship_score=data.get('stewardship_score', 0),
        spiritual_notes=data.get('spiritual_notes')
    )
    
    db.session.add(metrics)
    db.session.commit()
    
    return jsonify({'id': metrics.id, 'message': 'Abundance metrics recorded successfully'}), 201

# Financial Accounts and Transactions
@funding_bp.route('/finance/accounts', methods=['GET'])
def get_financial_accounts():
    """Get financial accounts for n8n integration"""
    dba_id = request.args.get('dba_id', type=int)
    
    query = FinancialAccount.query.filter_by(is_active=True)
    if dba_id:
        query = query.filter_by(dba_id=dba_id)
    
    accounts = query.all()
    result = []
    
    for account in accounts:
        account_data = {
            'id': account.id,
            'dba': account.dba_entity.name,
            'account_name': account.account_name,
            'account_type': account.account_type,
            'bank_name': account.bank_name,
            'current_balance': account.current_balance,
            'currency': account.currency,
            'type': 'revenue' if account.account_type in ['checking', 'savings', 'revenue'] else 'expense',
            'balance': account.current_balance
        }
        result.append(account_data)
    
    return jsonify(result)

@funding_bp.route('/finance/budgets', methods=['GET'])
def get_budgets():
    """Get budget information for n8n integration"""
    # This would typically come from a separate budgeting system
    # For now, return calculated budgets based on DBA targets
    
    entities = DBAEntity.query.all()
    result = []
    
    for entity in entities:
        budget_data = {
            'dba': entity.name,
            'monthly_revenue_target': entity.monthly_target,
            'annual_revenue_target': entity.annual_target,
            'monthly_expense_budget': entity.monthly_target * 0.7,  # Assume 70% expense ratio
            'profit_target': entity.monthly_target * 0.3
        }
        result.append(budget_data)
    
    return jsonify(result)

@funding_bp.route('/finance/transactions', methods=['POST'])
def record_transaction():
    """Record a new financial transaction"""
    data = request.get_json()
    
    transaction = Transaction(
        account_id=data['account_id'],
        transaction_type=data['transaction_type'],
        amount=data['amount'],
        currency=data.get('currency', 'USD'),
        description=data.get('description'),
        category=data.get('category'),
        reference_number=data.get('reference_number'),
        counterparty=data.get('counterparty'),
        transaction_date=datetime.strptime(data['transaction_date'], '%Y-%m-%d %H:%M:%S') if data.get('transaction_date') else datetime.utcnow(),
        spiritual_alignment_score=data.get('spiritual_alignment_score')
    )
    
    # Update account balance
    account = FinancialAccount.query.get(data['account_id'])
    if account:
        if data['transaction_type'] == 'credit':
            account.current_balance += data['amount']
        elif data['transaction_type'] == 'debit':
            account.current_balance -= data['amount']
        account.updated_at = datetime.utcnow()
    
    db.session.add(transaction)
    db.session.commit()
    
    return jsonify({'id': transaction.id, 'message': 'Transaction recorded successfully'}), 201

# Investor Communications
@funding_bp.route('/communications/investors', methods=['POST'])
def send_investor_communication():
    """Send communication to investors"""
    data = request.get_json()
    
    communication = InvestorCommunication(
        investor_id=data['investor_id'],
        communication_type=data['communication_type'],
        subject=data.get('subject'),
        content=data['content'],
        engagement_score=data.get('engagement_score'),
        spiritual_resonance=data.get('spiritual_resonance')
    )
    
    db.session.add(communication)
    db.session.commit()
    
    return jsonify({'id': communication.id, 'message': 'Communication sent successfully'}), 201

# Dashboard endpoints for n8n integration
@funding_bp.route('/dashboard/financial', methods=['POST'])
def update_financial_dashboard():
    """Update financial dashboard (for n8n integration)"""
    data = request.get_json()
    # In a real implementation, this would update a dashboard system
    # For now, just return success
    return jsonify({'message': 'Financial dashboard updated successfully'})

@funding_bp.route('/reports/investor', methods=['POST'])
def generate_investor_report():
    """Generate investor report (for n8n integration)"""
    data = request.get_json()
    # In a real implementation, this would generate and send reports
    # For now, just return success
    return jsonify({'message': 'Investor report generated successfully'})

@funding_bp.route('/alerts/financial', methods=['POST'])
def send_financial_alerts():
    """Send financial alerts (for n8n integration)"""
    data = request.get_json()
    # In a real implementation, this would send alerts via email/Slack
    # For now, just return success
    return jsonify({'message': 'Financial alerts sent successfully'})

# Spiritual Alignment Endpoints
@funding_bp.route('/spiritual/alignment', methods=['GET'])
def get_spiritual_alignment():
    """Get spiritual alignment metrics for all DBAs"""
    entities = DBAEntity.query.all()
    result = []
    
    for entity in entities:
        latest_metrics = AbundanceMetrics.query.filter_by(dba_id=entity.id).order_by(AbundanceMetrics.measurement_date.desc()).first()
        
        alignment_data = {
            'dba_id': entity.id,
            'dba_name': entity.name,
            'spiritual_mission': entity.spiritual_mission,
            'divine_alignment_score': latest_metrics.divine_alignment_score if latest_metrics else 0,
            'prosperity_flow_status': latest_metrics.prosperity_flow_status if latest_metrics else 'unknown',
            'stewardship_score': latest_metrics.stewardship_score if latest_metrics else 0,
            'generosity_capacity': latest_metrics.generosity_capacity if latest_metrics else 0,
            'spiritual_notes': latest_metrics.spiritual_notes if latest_metrics else ''
        }
        result.append(alignment_data)
    
    return jsonify(result)


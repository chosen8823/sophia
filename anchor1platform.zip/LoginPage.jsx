import React from 'react';
import { GoogleOAuthProvider } from '@react-oauth/google';
import GoogleSignIn from '@/components/GoogleSignIn';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';

const GOOGLE_CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID"; // This should be set from environment variables

const LoginPage = () => {
  const { user, authenticated, login, logout } = useAuth();

  // If user is already authenticated, redirect to dashboard
  if (authenticated && user) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              11:11 Alliance
            </h1>
            <p className="text-lg text-gray-600">
              Spiritual Abundance Platform
            </p>
            <div className="mt-4 text-sm text-gray-500">
              <p>✨ Divine Guidance Integration</p>
              <p>💰 Abundance Flow Management</p>
              <p>🤝 Operational Coordination</p>
            </div>
          </div>
          
          <GoogleSignIn 
            onAuthSuccess={login}
            user={user}
            onLogout={logout}
          />
          
          <div className="mt-8 text-center text-xs text-gray-400">
            <p>Powered by spiritual technology and divine alignment</p>
          </div>
        </div>
      </div>
    </GoogleOAuthProvider>
  );
};

export default LoginPage;


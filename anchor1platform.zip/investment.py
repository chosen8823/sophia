from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum

db = SQLAlchemy()

class InvestmentType(Enum):
    EQUITY = "equity"
    DEBT = "debt"
    GRANT = "grant"
    DONATION = "donation"
    REVENUE_SHARE = "revenue_share"

class InvestmentStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    FUNDED = "funded"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class DBAEntity(db.Model):
    __tablename__ = 'dba_entities'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    entity_type = db.Column(db.String(50), nullable=False)  # LLC, 501(c)(3), etc.
    jurisdiction = db.Column(db.String(50), nullable=False)
    ein = db.Column(db.String(20), unique=True)
    formation_date = db.Column(db.Date)
    description = db.Column(db.Text)
    monthly_target = db.Column(db.Float, default=0.0)
    annual_target = db.Column(db.Float, default=0.0)
    spiritual_mission = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    investments = db.relationship('Investment', backref='dba_entity', lazy=True)
    financial_accounts = db.relationship('FinancialAccount', backref='dba_entity', lazy=True)

class Investor(db.Model):
    __tablename__ = 'investors'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    investor_type = db.Column(db.String(50), nullable=False)  # individual, institutional, foundation
    accredited_status = db.Column(db.Boolean, default=False)
    spiritual_alignment_score = db.Column(db.Float, default=0.0)
    total_invested = db.Column(db.Float, default=0.0)
    preferred_investment_types = db.Column(db.Text)  # JSON string
    communication_preferences = db.Column(db.Text)  # JSON string
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    investments = db.relationship('Investment', backref='investor', lazy=True)
    communications = db.relationship('InvestorCommunication', backref='investor', lazy=True)

class Investment(db.Model):
    __tablename__ = 'investments'
    
    id = db.Column(db.Integer, primary_key=True)
    dba_id = db.Column(db.Integer, db.ForeignKey('dba_entities.id'), nullable=False)
    investor_id = db.Column(db.Integer, db.ForeignKey('investors.id'), nullable=False)
    investment_type = db.Column(db.Enum(InvestmentType), nullable=False)
    status = db.Column(db.Enum(InvestmentStatus), default=InvestmentStatus.PENDING)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    valuation_pre_money = db.Column(db.Float)
    equity_percentage = db.Column(db.Float)
    interest_rate = db.Column(db.Float)
    term_months = db.Column(db.Integer)
    funding_date = db.Column(db.Date)
    maturity_date = db.Column(db.Date)
    spiritual_alignment_notes = db.Column(db.Text)
    terms_and_conditions = db.Column(db.Text)
    due_diligence_completed = db.Column(db.Boolean, default=False)
    legal_documents_signed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    milestones = db.relationship('InvestmentMilestone', backref='investment', lazy=True)
    returns = db.relationship('InvestmentReturn', backref='investment', lazy=True)

class InvestmentMilestone(db.Model):
    __tablename__ = 'investment_milestones'
    
    id = db.Column(db.Integer, primary_key=True)
    investment_id = db.Column(db.Integer, db.ForeignKey('investments.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    target_date = db.Column(db.Date)
    completion_date = db.Column(db.Date)
    status = db.Column(db.String(50), default='pending')  # pending, in_progress, completed, delayed
    success_metrics = db.Column(db.Text)  # JSON string
    spiritual_impact = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class InvestmentReturn(db.Model):
    __tablename__ = 'investment_returns'
    
    id = db.Column(db.Integer, primary_key=True)
    investment_id = db.Column(db.Integer, db.ForeignKey('investments.id'), nullable=False)
    return_date = db.Column(db.Date, nullable=False)
    return_type = db.Column(db.String(50), nullable=False)  # dividend, interest, capital_return, profit_share
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    calculation_method = db.Column(db.Text)
    spiritual_value_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class FinancialAccount(db.Model):
    __tablename__ = 'financial_accounts'
    
    id = db.Column(db.Integer, primary_key=True)
    dba_id = db.Column(db.Integer, db.ForeignKey('dba_entities.id'), nullable=False)
    account_name = db.Column(db.String(100), nullable=False)
    account_type = db.Column(db.String(50), nullable=False)  # checking, savings, investment, revenue, expense
    bank_name = db.Column(db.String(100))
    account_number_encrypted = db.Column(db.String(200))  # Encrypted account number
    current_balance = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(3), default='USD')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    transactions = db.relationship('Transaction', backref='financial_account', lazy=True)

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    account_id = db.Column(db.Integer, db.ForeignKey('financial_accounts.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)  # credit, debit, transfer
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    description = db.Column(db.String(500))
    category = db.Column(db.String(100))  # revenue, expense, investment, etc.
    reference_number = db.Column(db.String(100))
    counterparty = db.Column(db.String(200))
    transaction_date = db.Column(db.DateTime, nullable=False)
    processed_date = db.Column(db.DateTime, default=datetime.utcnow)
    spiritual_alignment_score = db.Column(db.Float)  # How well this transaction aligns with mission
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Grant(db.Model):
    __tablename__ = 'grants'
    
    id = db.Column(db.Integer, primary_key=True)
    dba_id = db.Column(db.Integer, db.ForeignKey('dba_entities.id'), nullable=False)
    grant_name = db.Column(db.String(200), nullable=False)
    grantor_organization = db.Column(db.String(200), nullable=False)
    grant_type = db.Column(db.String(100))  # federal, state, foundation, corporate
    amount_requested = db.Column(db.Float, nullable=False)
    amount_awarded = db.Column(db.Float)
    currency = db.Column(db.String(3), default='USD')
    application_deadline = db.Column(db.Date)
    award_date = db.Column(db.Date)
    project_start_date = db.Column(db.Date)
    project_end_date = db.Column(db.Date)
    status = db.Column(db.String(50), default='researching')  # researching, applying, pending, awarded, rejected, completed
    application_submitted = db.Column(db.Boolean, default=False)
    reporting_requirements = db.Column(db.Text)
    spiritual_mission_alignment = db.Column(db.Text)
    project_description = db.Column(db.Text)
    success_metrics = db.Column(db.Text)  # JSON string
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    reports = db.relationship('GrantReport', backref='grant', lazy=True)

class GrantReport(db.Model):
    __tablename__ = 'grant_reports'
    
    id = db.Column(db.Integer, primary_key=True)
    grant_id = db.Column(db.Integer, db.ForeignKey('grants.id'), nullable=False)
    report_type = db.Column(db.String(50), nullable=False)  # progress, financial, final
    reporting_period_start = db.Column(db.Date)
    reporting_period_end = db.Column(db.Date)
    due_date = db.Column(db.Date, nullable=False)
    submission_date = db.Column(db.Date)
    status = db.Column(db.String(50), default='pending')  # pending, submitted, approved, revision_required
    report_content = db.Column(db.Text)
    financial_summary = db.Column(db.Text)  # JSON string
    impact_metrics = db.Column(db.Text)  # JSON string
    spiritual_impact_assessment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class InvestorCommunication(db.Model):
    __tablename__ = 'investor_communications'
    
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey('investors.id'), nullable=False)
    communication_type = db.Column(db.String(50), nullable=False)  # email, call, meeting, report
    subject = db.Column(db.String(200))
    content = db.Column(db.Text)
    sent_date = db.Column(db.DateTime, default=datetime.utcnow)
    response_received = db.Column(db.Boolean, default=False)
    response_date = db.Column(db.DateTime)
    response_content = db.Column(db.Text)
    engagement_score = db.Column(db.Float)  # How engaged the investor was
    spiritual_resonance = db.Column(db.Float)  # How well the communication resonated spiritually
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AbundanceMetrics(db.Model):
    __tablename__ = 'abundance_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    dba_id = db.Column(db.Integer, db.ForeignKey('dba_entities.id'), nullable=False)
    measurement_date = db.Column(db.Date, nullable=False)
    revenue_current_month = db.Column(db.Float, default=0.0)
    revenue_projected_annual = db.Column(db.Float, default=0.0)
    abundance_score = db.Column(db.Float, default=0.0)  # 0-100 scale
    divine_alignment_score = db.Column(db.Float, default=0.0)  # 0-100 scale
    prosperity_flow_status = db.Column(db.String(50))  # positive, blocked, neutral
    generosity_capacity = db.Column(db.Float, default=0.0)  # Amount available for charitable giving
    sustainability_rating = db.Column(db.String(50))  # excellent, good, adequate, minimal, unsustainable
    stewardship_score = db.Column(db.Float, default=0.0)  # 0-100 scale
    spiritual_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

